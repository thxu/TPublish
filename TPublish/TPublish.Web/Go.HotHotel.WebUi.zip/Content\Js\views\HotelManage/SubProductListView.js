﻿function showSubProductLayer(productId, productName, productExpla, isSubProduct) {
    $("#hidProductId").val(productId);
    var title = "修改附属产品";
    if (productId === "") {
        title = "添加附属产品";
        $("#txtProductName").val("");
        $("#txtProductExpla").val("");
    } else {
        $("#txtProductName").val(productName);
        $("#txtProductExpla").val(productExpla);
    }
    $("#chkIsSubProduct").prop("checked", isSubProduct === "2");
    openWindowForm(title, "#divSubProduct", "80%");
}

function saveSubProduct() {
    var productId = $("#hidProductId").val();
    var name = $.trim($("#txtProductName").val());
    var bizId = $("#hidBusinessId").val();
    var bizName = $("#hbusinessName").text();
    var isSubProduct = $("#chkIsSubProduct").prop("checked") === true ? 2 : 1;
    var productExpla = $.trim($("#txtProductExpla").val());
    if (name === "") {
        layer.alert("附属产品名称不能为空", { icon: 2 });
        return false;
    }
    var url = "/HotelManage/UpdateProduct";
    if (productId === "") {
        url = "/HotelManage/AddProduct";
    }

    var data = {
        ProductId: productId,
        BusinessId: bizId,
        BusinessName: bizName,
        ProductName: name,
        ProductType: 4,
        IsSubProduct: isSubProduct,
        ProductExpla: productExpla
    };
    data = JSON.stringify({ "info": data });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.alert("保存成功", function () {
                location.reload(true);
            });
        } else {
            layer.alert("保存失败，" + res.Message);
        }
    });
}

function updateProductStatus(productId, status) {
    var url = "/HotelManage/UpdateProductStatus";
    var data = JSON.stringify({ "productId": productId, "status": status });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.alert("更新成功", { icon: 1 }, function () {
                location.reload(true);
            });
        } else {
            layer.alert("更新失败，" + res.Message, { icon: 2 });
        }
    });
}



//加价管理
function showAddMoney(e) {
    var para = JSON.stringify({ "productId": e });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/QueryHolidayAddMoney",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d != null) {
                $("#dataList tbody").html($("#temp").tmpl(d));
                layer.open({
                    type: 1,
                    title: '加价管理',
                    area: ['460px', 'auto'],
                    fix: false, //不固定
                    maxmin: false,
                    content: $('#add-price-manage-tk')
                });
            } else {
                $.layerAlert("获取加价失败", { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//修改加价
function upHolidayAddMoney() {
    var info = [];
    var isErro = false;
    $("#dataList tbody tr").each(function () {
        var obj = new Object();
        obj.Id = parseInt($(this).attr("aId"));
        var addMoney = parseFloat($(this).children(".price").children().val());
        if (isNaN(addMoney)) {
            layer.tips("请输入数字", $(this).children(".price").children());
            isErro = true;
        }
        obj.AddMoney = addMoney;
        info.push(obj);
    });
    if (isErro) {
        return false;
    }
    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/UpHolidayAddMoney",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                layer.closeAll();
                $.layerAlert("修改成功", { icon: 1 });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return true;
};

//获取时间yyyy年M月d日
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + "年" + (date.getMonth() + 1) + "月" + date.getDate() + "日";
};