﻿$(function () {
    query();
    $("input[name='radType']").on("click", function () {
        if ($(this).val() === "0") {
            $("#divProductNums").hide();
            $("#divMoney").show();
        } else {
            $("#divProductNums").show();
            $("#divMoney").hide();
        }
    });
});
function query() {
    var para = JSON.stringify({ "businessId": parseInt($.trim($("#businesslId").val())) });
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/SelectDateProducts",
        success: function (d) {
            if (d != null) {
                $("#startTime").text(d.StartTime);
                $("#endTime").text(d.EndTime);
                for (var i = 0; i < d.ProductsInfo.length; i++) {
                    d.ProductsInfo[i].ReservationDate = d.ProductsInfo[i].ReservationDate.replace('-', '/')
                        .replace('-', '/');
                }
                $("#dataList").html($("#temp1").tmpl(d.ProductsInfo));
            }
        },
        complete: function () {
            $("#loading_warp").hide();
        }
    });
}
//批量库存管理
$(".inventory-manage-head button").click(function () {
    $("#inventory-modify-input").val("0");
    $("#inventory-reduce-modify-input").val("0");
    $("#price-modify-input").val("0");
    $("#price-reduce-modify-input").val("0");
    layer.open({
        type: 1,
        title: '批量修改库存(没有就新增)',
        area: ['380px', '455px'],
        fix: false, //不固定
        maxmin: false,
        content: $('#batch-inventory-modify-tk')
    });
});
//星期被选择
var week = document.getElementById('inlineRadio3');
var weakCheckBox = document.getElementsByClassName("numbers-change-week-checkbox")[0];
var singleDay = document.getElementById("inlineRadio1");
var doubleDay = document.getElementById('inlineRadio2');
singleDay.onclick = function () {
    weakCheckBox.className = 'numbers-change-week-checkbox hide';
}
doubleDay.onclick = function () {
    weakCheckBox.className = 'numbers-change-week-checkbox hide';
}
week.onclick = function () {
    weakCheckBox.className = 'numbers-change-week-checkbox';
}
//获取时间yyyy-MM-dd
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + PrefixInteger((date.getMonth() + 1), 2).toString() + PrefixInteger(date.getDate(), 2).toString();
};

//获取时间MM-dd
function getDateByMMdd(d) {
    var date = new Date(d);
    return PrefixInteger((date.getMonth() + 1), 2)
    + "-" + PrefixInteger(date.getDate(), 2);
};

//获取星期
function getWeek(d) {
    var week = new Date(d).getDay();
    if (week === 0) {
        return "日";
    } else if (week === 1) {
        return "一";
    } else if (week === 2) {
        return "二";
    } else if (week === 3) {
        return "三";
    } else if (week === 4) {
        return "四";
    } else if (week === 5) {
        return "五";
    } else if (week === 6) {
        return "六";
    }
    return "";
};

//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};

var date;
//修改库存
function upStock(e) {
    date = e.substring(0, 4) + "-" + e.substring(4, 6) + "-" + e.substring(6, 8);
    var para = JSON.stringify({ "businessId": parseInt($("#businesslId").val()), "date": e });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/QueryProductByDate",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d == null) {
                return false;
            }
            $("#dataList1 tbody").html($("#temp2").tmpl(d));
            // 库存修改
            layer.open({
                type: 1,
                title: '库存修改   ' + date,
                area: ['520px', 'auto'],
                fix: false, //不固定
                maxmin: false,
                content: $('#inventory-modify-tk')
            });
            return true;
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
//验证小数
function validateDoble(e) {
    var parem = $(e).val();
    if (parem === "") {
        parem = 0;
        $(e).val(parem);
    }
    var num = parseFloat(parem);
    if (isNaN(num)) {
        num = 0;
        $(e).val(num);
    }
    if (num < 0) {
        $(e).val("0");
    }
};
//验证整数
function validateInt(e, f) {
    var parem = $(e).val();
    if (parem === "") {
        if (f) {
            $(e).val("0");
        }
        return;
    }
    var num = parseInt(parem);
    if (isNaN(num)) {
        num = 0;
        $(e).val(num);
    } else {
        $(e).val(num);
    }
    if (num < 0) {
        $(e).val("0");
    }
};

// 单日修改
function savehouseType() {
    var info = [];
    var businessId = parseInt($("#businesslId").val());
    var isErro = false;
    $("#dataList1 tbody tr").each(function () {
        var obj = new Object();
        obj.ProductId = $(this).attr("pId");
        obj.BusinessId = businessId;
        obj.ReservationDate = date;
        var money = parseFloat($(this).children(".price").children().val());
        if (isNaN(money)) {
            isErro = true;
            layer.tips("请输入数字", $(this).children(".price").children());
            return;
        }
        obj.AddMoney = money;
        var nums = $(this).children(".stock").children().val();
        if (nums === "") {
            nums = -1;
        }
        nums = parseInt(nums);
        if (isNaN(nums)) {
            isErro = true;
            layer.tips("请输入整数", $(this).children(".stock").children());
            return;
        }
        obj.ProductNums = nums;
        info.push(obj);
    });
    if (isErro) {
        return false;
    }
    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/UpdateStockBySingle",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                query();
                $.layerAlert("修改成功", { icon: 1 });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

// 保存批量修改
function saveBatchStock() {
    if ($.trim($("#inventory-modify-start-time-input").val()) === "") {
        $.layerAlert("请输入开始时间", { icon: 2 });
        return false;
    }

    if ($.trim($("#inventory-modify-end-time-input").val()) === "") {
        $.layerAlert("请输入结束时间", { icon: 2 });
        return false;
    }
    var timeType = $("input[name='inlineRadioOptions']:checked").val();
    var scheduleLimit = "";
    if (timeType === "3") {
        if ($("#chklWeek_1").prop("checked") === true) {
            scheduleLimit = "1";
        }
        if ($("#chklWeek_2").prop("checked") === true) {
            scheduleLimit += "/2";
        }
        if ($("#chklWeek_3").prop("checked") === true) {
            scheduleLimit += "/3";
        }
        if ($("#chklWeek_4").prop("checked") === true) {
            scheduleLimit += "/4";
        }
        if ($("#chklWeek_5").prop("checked") === true) {
            scheduleLimit += "/5";
        }
        if ($("#chklWeek_6").prop("checked") === true) {
            scheduleLimit += "/6";
        }
        if ($("#chklWeek_7").prop("checked") === true) {
            scheduleLimit += "/0";
        }
        if (scheduleLimit.indexOf("/") === 0) {
            scheduleLimit = scheduleLimit.substr(1);
        }
        if (scheduleLimit === "") {
            $.layerAlert("至少选择一个星期天数", { icon: 2 });
            return false;
        }
    }

    var addMoney = parseFloat($("#price-modify-input").val());
    if (isNaN(addMoney)) {
        layer.tips("请输入数字", $("#price-modify-input"));
        return false;
    }
    var reduceMoney = parseFloat($("#price-reduce-modify-input").val());
    if (isNaN(reduceMoney)) {
        layer.tips("请输入数字", $("#price-reduce-modify-input"));
        return false;
    }
    var money = addMoney - reduceMoney;
    var addStock = parseInt($("#inventory-modify-input").val());
    if (isNaN(addStock)) {
        layer.tips("请输入整数", $("#inventory-modify-input"));
        return false;
    }
    var reduceStock = parseInt($("#inventory-reduce-modify-input").val());
    if (isNaN(reduceStock)) {
        layer.tips("请输入整数", $("#inventory-reduce-modify-input"));
        return false;
    }
    var stock = addStock - reduceStock;

    var info = {
        ProductId: $("#products").val(),
        BusinessId: parseInt($("#businesslId").val()),
        TimeType: timeType,
        WeekLimit: scheduleLimit,
        ReservationStartDate: $("#inventory-modify-start-time-input").val(),
        ReservationEndDate: $("#inventory-modify-end-time-input").val(),
        AddMoney: money,
        ProductNums: stock
    };

    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HotelManage/BatchUpdateStock",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                query();
                $.layerAlert("操作成功", { icon: 1 });
            } else {
                $.layerAlert("操作失败", { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}