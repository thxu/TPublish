﻿$(document).ready(function () {
    // 浏览器点击后退样式问题
    $("#firstMenu li[class='active']").attr("class", "");
    if ($("#firstMenu li[id='F1']").val() != undefined) {
        $("#firstMenu li[id='F1']").attr("class", "active");
    } else {
        $("#firstMenu li[id='F10']").attr("class", "active");
    }
    queryhotel();
    $("#txtProductId").change(function () {
        var begin = $.trim($("#txtProductId option:selected").attr("start"));
        var end = $.trim($("#txtProductId option:selected").attr("end"));
        $("#resStartDate").val(getDate(begin));
        $("#resEndDate").val(getDate(end));
    });

    $('.hotel-manage-list-dispatch-rule-delete').click(function () {
        $(this).parent().parent().remove();
        //更新规则名称
        $('.hotel-manage-list-dispatch-rule').each(function (index, element) {
            element.html('规则' + Arabia_To_SimplifiedChinese(index));
        });
    });
    $("input[name='SelectALL']").click(function () {
        if ($(this).prop('checked') === false) {
            $(this).parent().parent().find('input').each(function () {
                $(this).prop("checked", false);
            });
        } else {
            $(this).parent().parent().find('input').each(function () {
                $(this).prop("checked", true);
            });
        }
    });
});

// 条件
function getCondition() {
    var obj = new Object();
    obj.BusinessName = $.trim($("#txtqueryBusinessName").val());
    return obj;
}

// 查询会员信息
function queryhotel(pageIndex, pageSize) {
    pagingQuery(pageIndex, pageSize, "/HotelManage/HotelManageVal", getCondition(), queryhotel);
}

// div显示
function showhoteldiv(businesslId) {
    // 清空数据，还原账号密码框
    $("#divLoginId").show();
    $("#divLoginPwd").show();
    $("#txtProductId").html("");
    $("#hidBusinesslId").val("");
    $("#txtBusinessName").val("");
    $("#txtBusinessAddress").val("");
    $("#txtBusinesslTel").val("");
    $("#txtSaleTel").val("");
    $("#txtDutyTel").val("");
    $("#txtRemark").val("");
    $("#txtLoginId").val("");
    $("#txtLoginPwd").val("");
    $("#txtReserveRatio").val("");
    $("#divresEncryptUrl").hide();
    $("#divreserveresEncryptUrl").hide();

    var content = '<div class="hotel-manage-list-dispatch-rule-one" name="Stock"><div><span class="hotel-manage-list-dispatch-rule">规则一</span><i class="hotel-manage-list-dispatch-rule-delete  fa fa-times-circle-o" style="font-size: 20px" aria-hidden="true"></i></div><div class="hotel-manage-list-dispatch-week-box"><label class="radio-inline"><input type="checkbox" value="" class="hotel-manage-list-dispatch-week-all-select" name="SelectALL">&nbsp;全选 </label> <label class="radio-inline"><input type="checkbox" name="week"  value="1">&nbsp;周一</label> <label class="radio-inline"> <input type="checkbox" name="week"  value="2">&nbsp;周二 </label> <label class="radio-inline"> <input type="checkbox" name="week" value="3">&nbsp;周三 </label> <label class="radio-inline"> <input type="checkbox" name="week" value="4">&nbsp;周四 </label> <label class="radio-inline"> <input type="checkbox" name="week" value="5">&nbsp;周五 </label> <label class="radio-inline"> <input type="checkbox" name="week" value="6">&nbsp;周六 </label> <label class="radio-inline"> <input type="checkbox" name="week" value="7">&nbsp;周日 </label> </div> <div class="row hotel-manage-list-dispatch-rule-time-section-box"> <div class="col-sm-3"> <span class="hotel-manage-list-dispatch-rule-time-section">规则时间段选取</span> </div> <div class="col-sm-9"> <div class="row"> <div class="col-sm-5"> <input type="text" class="form-control" name="BeginTime" onclick="WdatePicker({ doubleCalendar: true, dateFmt: \'yyyy-MM-dd\' })"></div> <div class="col-sm-1"> <span class="hotel-manage-list-dispatch-rule-middle-text">至 </span> </div> <div class=" col-sm-5"> <input type="text" class="form-control" name="EndTime" onclick="WdatePicker({ doubleCalendar: true, dateFmt: \'yyyy-MM-dd\' })"> </div> </div> </div> </div> <div class="row hotel-manage-list-dispatch-rule-time-section-box"> <div class="col-sm-3"> <span class="hotel-manage-list-dispatch-rule-time-section">储备库存比例设置</span> </div> <div class="col-sm-9"> <div class="row"> <div class="col-sm-5"> <input type="text" name="Ratio" class="form-control" onkeyup="value = value.replace(/[^0-9.]/g, "");"> </div> <div class="col-sm-1"> <span class="hotel-manage-list-dispatch-rule-middle-text">%</span> </div> </div> </div> </div> <div class="border-bottom hotel-manage-list-dispatch-rule-cutting-line"></div> </div>';
    $('.hotel-manage-list-dispatch-rule-parent').html(content);
    // 查询微商产品名称
    var productIdhtml = "<option value=''>请选择</option>";


    if (businesslId !== "") {
        $("#divresEncryptUrl").show();
        $("#divreserveresEncryptUrl").show();
        $("#hidBusinesslId").val(businesslId);
        $("#divLoginId").hide();
        $("#divLoginPwd").hide();
        var para = JSON.stringify({ "businesslId": businesslId });
        $.ajaxExtend({
            data: para,
            url: "/HotelManage/QueryBusinessByBusinessId",
            success: function (data) {
                if (data !== null && data != undefined) {
                    console.log(data);
                    operationAction("/HotelManage/QueryProductsToHotel", "", function (d) {
                        if (d != null && d.length > 0) {
                            for (var i = 0; i < d.length; i++) {
                                productIdhtml += "<option start='" + d[i].BeginTime + "' end='" + d[i].EndTime + "' value='" + d[i].ProductsId + "'>" + d[i].ProductsName + "</option>";
                            }
                            $("#txtProductId").html(productIdhtml);
                            if (data.BusinessManager.ProductId !== "") {
                                $("#txtProductId option[value='" + data.BusinessManager.ProductId + "']").prop("selected", true);
                            }
                        }
                    });

                    // 储备库存比例规则
                    if (data.ReserveRatioList != null && data.ReserveRatioList.length > 0) {
                        $('.hotel-manage-list-dispatch-rule-parent').html("");
                        for (var i = 0; i < data.ReserveRatioList.length; i++) {
                            var chinaNum = Arabia_To_SimplifiedChinese(i + 1);
                            var radio = getRatio(data.ReserveRatioList[i]);
                            var beginTime = data.ReserveRatioList[i].BeginTime.substring(0, 10);
                            var endTime = data.ReserveRatioList[i].EndTime.substring(0, 10);
                            var content = '<div class="hotel-manage-list-dispatch-rule-one" name="Stock"><div><span class="hotel-manage-list-dispatch-rule">规则' + chinaNum + '</span><i class="hotel-manage-list-dispatch-rule-delete  fa fa-times-circle-o" style="font-size: 20px" aria-hidden="true"></i></div><div class="hotel-manage-list-dispatch-week-box"> <label class="radio-inline"><input type="checkbox" value="" class="hotel-manage-list-dispatch-week-all-select" name="SelectALL">&nbsp;全选</label>';
                            content += (" <label class='radio-inline'><input type='checkbox' name='week' " + GetIschecked(data.ReserveRatioList[i].MondayRatio) + "  value='1'>&nbsp;周一</label>");
                            content += "<label class='radio-inline'> <input type='checkbox' name='week'  " + GetIschecked(data.ReserveRatioList[i].TuesdaysRatio) + " value='2'>&nbsp;周二 </label>";
                            content += " <label class='radio-inline'> <input type='checkbox' name='week'" + GetIschecked(data.ReserveRatioList[i].WednesdayRatio) + "  value='3'>&nbsp;周三 </label>";
                            content += " <label class='radio-inline'> <input type='checkbox' name='week'" + GetIschecked(data.ReserveRatioList[i].ThursdayRatio) + "  value='4'>&nbsp;周四 </label>";
                            content += " <label class='radio-inline'> <input type='checkbox' name='week'" + GetIschecked(data.ReserveRatioList[i].FridayRatio) + "  value='5'>&nbsp;周五 </label>";
                            content += " <label class='radio-inline'> <input type='checkbox' name='week'" + GetIschecked(data.ReserveRatioList[i].SaturdayRatio) + "  value='6'>&nbsp;周六 </label>";
                            content += " <label class='radio-inline'> <input type='checkbox' name='week'" + GetIschecked(data.ReserveRatioList[i].SundayRatio) + "  value='7'>&nbsp;周日 </label> </div>";
                            content += " <div class='row hotel-manage-list-dispatch-rule-time-section-box'> <div class='col-sm-3'> <span class='hotel-manage-list-dispatch-rule-time-section'>规则时间段选取</span> </div> <div class='col-sm-9'> <div class='row'> <div class='col-sm-5'>";
                            content += "<input type='text' class='form-control' name='BeginTime' value='" + beginTime + "' onclick=\"WdatePicker({ doubleCalendar: true, dateFmt: 'yyyy-MM-dd' })\"></div> <div class='col-sm-1'> <span class='hotel-manage-list-dispatch-rule-middle-text'>至 </span> </div> <div class='col-sm-5'> ";
                            content += "<input type='text' class='form-control' name='EndTime' value='" + endTime + "' onclick=\"WdatePicker({ doubleCalendar: true, dateFmt: 'yyyy-MM-dd' })\"> </div> </div> </div> </div> ";
                            content += "<div class='row hotel-manage-list-dispatch-rule-time-section-box'> <div class='col-sm-3'> <span class='hotel-manage-list-dispatch-rule-time-section'>储备库存比例设置</span> </div> <div class='col-sm-9'> <div class='row'> <div class='col-sm-5'>";
                            content += " <input type='text' name='Ratio' value='" + radio + "' class='form-control' onkeyup=\"value = value.replace(/[^0-9.]/g, '');\"> </div> <div class='col-sm-1'> <span class='hotel-manage-list-dispatch-rule-middle-text'>%</span> </div> </div> </div> </div> <div class='border-bottom hotel-manage-list-dispatch-rule-cutting-line'></div> </div>";
                            $('.hotel-manage-list-dispatch-rule-parent').append(content);
                        }
                    }




                    $("#txtBusinessName").val(data.BusinessManager.BusinessName);
                    $("#txtBusinessAddress").val(data.BusinessManager.BusinessAddress);
                    $("#txtBusinesslTel").val(data.BusinessManager.BusinesslTel);
                    $("#txtSaleTel").val(data.BusinessManager.SaleTel);
                    $("#txtDutyTel").val(data.BusinessManager.DutyTel);
                    $("#resStartDate").val(getDate(data.BusinessManager.ResValidityBeginDate));
                    $("#resEndDate").val(getDate(data.BusinessManager.ResValidityEndDate));
                    $("#resStartTime").val(data.BusinessManager.ResValidityBeginTime);
                    $("#resEndTime").val(data.BusinessManager.ResValidityEndTime);
                    if (data.BusinessManager.ResEncryptUrl !== "") {
                        if (data.BusinessManager.ResEncryptUrl.indexOf("|") !== -1) {
                            var array = data.BusinessManager.ResEncryptUrl.split('|');
                            $("#resEncryptUrl").val(array[0]);
                            $("#reserveresEncryptUrl").val(array[1]);
                        } else {
                            $("#resEncryptUrl").val(data.BusinessManager.ResEncryptUrl);
                        }

                    }
                    // $("#resEncryptUrl").val(data.ResEncryptUrl);
                    //$("#txtReserveRatio").val(data.ReserveRatio);
                    $("input[name='isNeedReservation'][value='" + data.BusinessManager.IsNeedReservation + "']").prop("checked", true);
                    // $("#txtRemark").val(data.Remark);
                    editor.setValue(data.BusinessManager.Remark);

                    $('.hotel-manage-list-dispatch-rule-delete').click(function () {
                        $(this).parent().parent().remove();
                        //更新规则名称
                        $('.hotel-manage-list-dispatch-rule').each(function (index, element) {
                            element.html('规则' + Arabia_To_SimplifiedChinese(index));
                        });
                    });
                    $("input[name='SelectALL']").click(function () {
                        if ($(this).prop('checked') === false) {
                            $(this).parent().parent().find('input').each(function () {
                                $(this).prop("checked", false);
                            });
                        } else {
                            $(this).parent().parent().find('input').each(function () {
                                $(this).prop("checked", true);
                            });
                        }
                    });
                }
            }
        });
    } else {
        operationAction("/HotelManage/QueryProductsToHotel", "", function (data) {
            if (data != null && data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    productIdhtml += "<option start='" + data[i].BeginTime + "' end='" + data[i].EndTime + "' value='" + data[i].ProductsId + "'>" + data[i].ProductsName + "</option>";
                }
                $("#txtProductId").html(productIdhtml);

                $('.hotel-manage-list-dispatch-rule-delete').click(function () {
                    $(this).parent().parent().remove();
                    //更新规则名称
                    $('.hotel-manage-list-dispatch-rule').each(function (index, element) {
                        element.html('规则' + Arabia_To_SimplifiedChinese(index));
                    });
                });
                $("input[name='SelectALL']").click(function () {
                    if ($(this).prop('checked') === false) {
                        $(this).parent().parent().find('input').each(function () {
                            $(this).prop("checked", false);
                        });
                    } else {
                        $(this).parent().parent().find('input').each(function () {
                            $(this).prop("checked", true);
                        });
                    }
                });
            }
        });

       
    }

    layer.open({
        type: 1,
        title: '爆款酒店',
        area: ['80%', '90%'],
        fix: false, //不固定
        maxmin: false,
        content: $('#divhotel')
    });
}

function GetIschecked(value) {
    return value > 0 ? 'checked=checked' : "";
}


// 日期截取
function getCreatDate(creatDate) {
    return creatDate.substring(0, 10);
}

function getIsNeedReservation(isNeedReservation) {
    return isNeedReservation === 1 ? "<span style='color:green'>免预约</span>" : "需预约";
}

//获取储备比例
function getRatio(data) {
    if (data.MondayRatio > 0) {
        return data.MondayRatio;
    } else if (data.TuesdaysRatio > 0) {
        return data.TuesdaysRatio;
    } else if (data.WednesdayRatio > 0) {
        return data.WednesdayRatio;
    } else if (data.ThursdayRatio > 0) {
        return data.ThursdayRatio;
    } else if (data.FridayRatio > 0) {
        return data.FridayRatio;
    } else if (data.SaturdayRatio > 0) {
        return data.SaturdayRatio;
    } else if (data.SundayRatio > 0) {
        return data.MondayRatio;
    }
    return data.MondayRatio;
};

// 保存酒店
function saveHotel() {
    var isSave = true;
    if ($.trim($("#txtProductId").val()) === "") {
        $.layerAlert("产品不能为空", { icon: 2 });
        return false;
    }
    if ($.trim($("#txtBusinessName").val()) === "") {
        $.layerAlert("标题不能为空", { icon: 2 });
        return false;
    }
    var reserveRatio = parseInt($.trim($("#txtReserveRatio").val()));
    if (reserveRatio !== "") {
        if (reserveRatio < 0 || reserveRatio > 100) {
            $.layerAlert("请输入正确的比例范围", { icon: 2 });
            return false;
        }
    }
    if ($("#hidBusinesslId").val() === "" && $.trim($("#txtLoginId").val()) === "") {
        $.layerAlert("账号不能为空", { icon: 2 });
        return false;
    }
    var ratioList = [];
    $("div[name='Stock']").each(function (index) {
        var reserveratio = {};
        reserveratio.BusinessId = $("#hidBusinesslId").val();

        reserveratio.BeginTime = $(this).find("input[name='BeginTime']").val();
        reserveratio.EndTime = $(this).find("input[name='EndTime']").val();
        if (reserveratio.BeginTime === "") {
            $.layerAlert("规则" + (index + 1) + "开始时间不能为空", { icon: 2 });
            isSave = false;
            return false;
        }
        if (reserveratio.EndTime === "") {
            $.layerAlert("规则" + (index + 1) + "结束时间时间不能为空", { icon: 2 });
            isSave = false;
            return false;
        }
      

        var dateStar = new Date(reserveratio.BeginTime);
        var dateEnd = new Date(reserveratio.EndTime);
        if (dateStar > dateEnd ) {
            $.layerAlert("规则" + (index + 1) + "开始时间不能大于结束时间", { icon: 2 });
            isSave = false;
            return false;
        }

        var ratio = $(this).find("input[name='Ratio']").val();

        if ($(this).find("input[name='week']").length === 0) {
            $.layerAlert("规则" + (index + 1) + "至少选择一个星期日期", { icon: 2 });

            isSave = false;
            return false;
        }

        if (ratio === "") {
            $.layerAlert("规则" + (index + 1) + "储备库存比例不能为空", { icon: 2 });
            isSave = false;
            return false;
        }
        $(this).find("input[name='week']").each(function () {
            if (this.checked) {

                if ($(this).val() === "1") {
                    reserveratio.MondayRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "2") {
                    reserveratio.TuesdaysRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "3") {
                    reserveratio.WednesdayRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "4") {
                    reserveratio.ThursdayRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "5") {
                    reserveratio.FridayRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "6") {
                    reserveratio.SaturdayRatio = parseFloat(ratio) / 100;
                }
                if ($(this).val() === "7") {
                    reserveratio.SundayRatio = parseFloat(ratio) / 100;
                }
            }
        });
        ratioList.push(reserveratio);
    });

    if (!isSave) {
        return false;
    }
    var info = {
        ProductId: $("#txtProductId").val(),
        BusinessId: $("#hidBusinesslId").val(),
        BusinessName: $.trim($("#txtBusinessName").val()),
        BusinessAddress: $.trim($("#txtBusinessAddress").val()),
        BusinesslTel: $.trim($("#txtBusinesslTel").val()),
        SaleTel: $.trim($("#txtSaleTel").val()),
        DutyTel: $.trim($("#txtDutyTel").val()),
        Remark: $.trim($("#txtRemark").val()),
        LoginId: $.trim($("#txtLoginId").val()),
        LoginPwd: $.trim($("#txtLoginPwd").val()),
        IsNeedReservation: parseInt($.trim($("input:radio:checked").val())),
        ResValidityBeginDate: $.trim($("#resStartDate").val()),
        ResValidityEndDate: $.trim($("#resEndDate").val()),
        ResValidityBeginTime: parseInt($.trim($("#resStartTime").val())),
        ResValidityEndTime: parseInt($.trim($("#resEndTime").val())),
        ResEncryptUrl: $.trim($("#resEncryptUrl").val()) + "|" + $.trim($("#reserveresEncryptUrl").val()),
        ReserveRatio: $.trim($("#txtReserveRatio").val())
    };
    var url;
    if ($("#hidBusinesslId").val() === "") {
        url = "/HotelManage/AddHotelManage";
    } else {
        url = "/HotelManage/UpdateHotelManage";
    }
    var para = JSON.stringify({ "info": info, "ratioList": ratioList });
    var load;
    $.ajaxExtend({
        data: para,
        url: url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                $.layerAlert("操作成功", { icon: 1 });
                queryhotel();
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

function deleteHotel(businessId) {
    var para = JSON.stringify({ "businessId": businessId });
    confirmAction("确认删除吗？", function (d) {
        operationAction("/HotelManage/DeletedBusiness", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("删除成功", { icon: 1 });
                queryhotel();
            } else {
                $.layerAlert("删除失败", { icon: 2 });
            }

        });
    });

    return false;
}

//获取时间yyyy-MM-dd
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + "-" + PrefixInteger((date.getMonth() + 1), 2).toString() + "-" + PrefixInteger(date.getDate(), 2).toString();
};

//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};

function getUrl(resEncryptUrl, position, businessId) {
    if (resEncryptUrl !== "" && resEncryptUrl.indexOf("|") !== -1) {
        var array = resEncryptUrl.split('|');
        if (position === 0) {
            if (array[0] === "") {
                var str = "【短链获取失败,原链接为http://http://hothotel.dongzouxizou.cn/Reservation/SelectDate?businessId=" + businessId + "】";
                return '<span title=' + str + '>短链获取失败....</span>';
            } else {
                return array[0];
            }

        }
        if (position === 1) {
            if (array[1] === "") {
                var arraystr = "【短链获取失败,原链接为http://http://hothotel.dongzouxizou.cn/Reservation/SelectDateByReserve?businessId=" + businessId + "】";
                return '<span title=' + arraystr + '>短链获取失败....</span>';

            } else {
                return array[1];
            }
        }

    } else {
        return "【异步获取中,请稍后查看...】";
    }

    return "";
}