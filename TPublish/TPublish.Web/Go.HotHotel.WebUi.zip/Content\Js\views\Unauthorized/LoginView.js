﻿function login() {
    var loginId = $.trim($("#txtLoginId").val());
    var loginPwd = $.trim($("#txtLoginPwd").val());
    var url = "/Unauthorized/Login";
    var data = JSON.stringify({ "loginId": loginId, "pwd": loginPwd });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            window.location.href = "/Home/Index";
        } else {
            layer.alert("登录失败," + res.Message);
        }
    });
}