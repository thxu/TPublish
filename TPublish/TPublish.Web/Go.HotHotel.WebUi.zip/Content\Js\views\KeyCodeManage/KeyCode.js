﻿$(document).ready(function () {
    // 浏览器点击后退样式问题
    $("#firstMenu li[class='active']").attr("class", "");

    if ($("#firstMenu li[id='F5']").val() != undefined) {
        $("#firstMenu li[id='F5']").attr("class", "active");
    } else {
        $("#firstMenu li[id='F12']").attr("class", "active");
    }
    $(".tianjia").click(function () {  //添加与修改
        layer.open({
            type: 1,
            title: '订单导入',
            area: ['460px', 'auto'],
            fix: false, //不固定
            maxmin: false,
            content: $('#tianjia-tk')
        });
    });

    $(".tianjia2").click(function () {  //添加与修改
        layer.open({
            type: 1,
            title: '电子码自动生成',
            area: ['460px', 'auto'],
            fix: false, //不固定
            maxmin: false,
            content: $('#tianjia2-tk')
        });
    });
});
function getCondition() {
    var obj = new Object();
    obj.KeyCode = $.trim($("#searchKeyCode").val());
    obj.KeyStatus = parseInt($.trim($("#keyStatus").val()));
    obj.UserPhone = $.trim($("#userPhone").val());
    obj.BusinessName = $.trim($("#txtBusinessName").val());
    obj.UserName = $.trim($("#txtUserName").val());
    obj.OrderNumber = $.trim($("#txtOrderNumber").val());
    obj.MsgSendState = $.trim($("#selectSendStatus").val());
    obj.CreateTimeStart = $.trim($("#BeginTime").val());
    obj.CreateTimeEnd = $.trim($("#EndTime").val());
    return obj;
}
// 查询
function queryKeyCode(pageIndex, pageSize) {
    pagingQuery(pageIndex, pageSize, "/KeyCodeManage/QueryKeyCode", getCondition(), queryKeyCode);
}

//生成code
function createKeyCode() {
    var obj = new Object();
    obj.BusinessId = parseInt($.trim($("#generateKeyCode").val()));
    obj.CodeCount = parseInt($.trim($("#codeNumber").val()));
    var timeBegin = $.trim($("#CreateTimeStart").val());
    if (timeBegin === "") {
        layer.tips("不能为空", $("#CreateTimeStart"));
        return;
    }
    var timeEnd = $.trim($("#CreateTimeEnd").val());
    if (timeEnd === "") {
        layer.tips("不能为空", $("#CreateTimeEnd"));
        return;
    }
    obj.DateBegin = timeBegin;
    obj.DateEnd = timeEnd;

    var para = JSON.stringify({ "codeInfo": obj });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/KeyCodeManage/SetKeyCode",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (result) {
            if (result.IsSucceed) {
                layer.closeAll();
                queryKeyCode();
                layer.alert(result.Message, { icon: 1, title: "提示" });
            } else {
                layer.alert(result.Message, { icon: 2, title: "提示" });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//改变状态
function changeStates(i, isFf) {
    var obj = new Object();
    obj.Id = parseInt(i);
    obj.KeyStatus = parseInt(isFf);
    var para = JSON.stringify({ "codeInfo": obj });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/KeyCodeManage/ChangeCodeStates",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (result) {
            if (result.IsSucceed) {
                layer.closeAll();
                queryKeyCode();
                layer.msg("操作成功");
            } else {
                layer.alert(result.Message, { icon: 2, title: "提示" });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//全选
function selectAll(e) {
    if (!$(e).is(":checked")) {
        $("input:checkbox[name='checkbox2']").each(function () {
            $(this).removeAttr("checked");
        });
    } else {
        $("input:checkbox[name='checkbox2']").each(function () {
            var txt = $.trim($(this).parent().siblings(".status").children(".KeyStatus").text());
            if ((txt === "未发放" || txt === "已发放") && $.trim($(this).parent().siblings(".userInfo").text()) !== "") {
                $(this).prop("checked", "true");
            }
        });
    }
};
// 按勾选批量补发短信
function sendSmsByChk() {
    var userInfo = [];
    $("input:checkbox[name='checkbox2']:checked").each(function () {
        var status = $.trim($(this).parent().siblings(".status").children(".KeyStatus").text());
        if ($.trim($(this).parent().siblings(".userInfo").text()) !== "" && (status === "未发放" || status === "已发放")) {
            var obj = new Object();
            obj.Id = parseInt($.trim($(this).parent().siblings(".userInfo").attr("kid")));
            obj.UserName = $.trim($(this).parent().siblings(".userInfo").children(".uName").text());
            obj.UserPhone = $.trim($(this).parent().siblings(".userInfo").children(".uPhone").text());
            obj.OrderNumber = $.trim($(this).parent().siblings(".userInfo").children(".uOrder").text());
            obj.EndTime = $.trim($(this).parent().siblings(".endTime").attr("dt"));
            obj.BusinessId = $.trim($(this).parent().siblings(".bid").attr("bid"));
            userInfo.push(obj);
        }
    });
    if (userInfo.length === 0) {
        $("#checkbox").removeAttr("checked");
        layer.msg("没有已分配的电子码");
        return;
    }
    var title = "共有" + userInfo.length + "条短信需要发送，确认发送吗？";
    confirmAction(title, function () {
        var para = JSON.stringify({ "coderInfo": userInfo });
        operationAction("/KeyCodeManage/SendSms", para, function (result) {
            if (result.IsSucceed) {
                layer.closeAll();
                queryKeyCode();
                layer.alert(result.Message, { icon: 1, title: "提示" });
                $("#checkbox").removeAttr("checked");
            } else {
                layer.alert(result.Message, { icon: 2, title: "提示" });
            }
        });
    });
};

// 按查询条件批量补发短信
function sendSmsByCondition() {
    var url = "/KeyCodeManage/SendSmsByCondition";
    var data = JSON.stringify({ "condition": getCondition() });

    operationAction("/KeyCodeManage/QueryCntOfSms", data, function (cnt) {
        if (cnt) {
            var title = "共有" + cnt + "条短信需要发送，确认发送吗？";
            confirmAction(title, function () {
                operationAction(url, data, function (result) {
                    if (result.IsSucceed) {
                        layer.closeAll();
                        queryKeyCode();
                        layer.alert(result.Message, { icon: 1, title: "提示" });
                        $("#checkbox").removeAttr("checked");
                    } else {
                        layer.alert(result.Message, { icon: 2, title: "提示" });
                    }
                });
            });
        } else {
            $("#checkbox").removeAttr("checked");
            layer.msg("没有已分配的电子码");
            return;
        }
    });
}

//上传订单
function upload() {
    var file = document.myForm.fileName.files[0];
    if (file === undefined) {
        layer.msg("未选择文件");
        return;
    }
    if ($.trim($("#dropStaffId").val()) === "") {
        layer.msg("请选择关联员工");
        return false;
    }
    var businessId = parseInt($.trim($("#keyCodeS").val()));
    var employeeId = parseInt($.trim($("#dropStaffId").val()));

    var fm = new FormData();
    fm.append("fileT", file);
    var load;
    $.ajaxExtend({
        data: fm,
        url: "/KeyCodeManage/UploadFile?businessId=" + businessId + "&employeeId=" + employeeId,
        contentType: false,
        processData: false,
        type: "POST",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (result) {
            if (result.IsSucceed) {
                layer.closeAll();
                queryKeyCode();
                layer.alert(result.Message, { icon: 1, title: "提示" });
                var obj = document.getElementById("fileId");
                obj.outerHTML = obj.outerHTML;
            } else {
                layer.alert(result.Message, { icon: 2, title: "提示" });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

function getName(e) {
    if (e === "") {
        return "";
    }
    return "姓名：<span class='uName'>" + e + "</span><br>";
};
function getPhone(e) {
    if (e === "") {
        return "";
    }
    return "手机：<span class='uPhone'>" + e + "</span>";
};
function getOrderNub(e) {
    if (e === "") {
        return "";
    }
    return "订单号：<span class='uOrder'>" + e + "</span>";
};
function getKeyCodeStatusText(status) {
    switch (status) {
        case 10:
            return "<span class='KeyStatus' style='color: #F00'>已作废</span>";
        case 11:
            return "<span class='KeyStatus' style='color: #093'>未发放</span>";
        case 12:
            return "<span class='KeyStatus' style='color: #06C'>已发放</span>";
        case 13:
            return "<span class='KeyStatus' style='color: #de6a14'>已使用</span>";
        case 14:
            return "<span class='KeyStatus' style='color: #F00'>已挂起</span>";
            //case 4:
            //    return "已预定，无需确认";
            //case 5:
            //    return "已预定，已确认";
            //case 6:
            //    return "已线下使用";
        default:
            return "未知";
    }
}

function closeForm() {
    layer.closeAll();
    var obj = document.getElementById("fileId");
    obj.outerHTML = obj.outerHTML;
};

// 批量删除
function batchdeletecode() {
    var idList = "";
    $("input[name='checkbox2']").each(function () {
        if ($(this)[0].checked === true) {
            idList += $(this).val() + '^';
        }
    });

    if (idList.length === 0) {
        $.layerAlert("操作失败,请至少选择一个电子码", { icon: 2 });
        return false;
    }
    var para = JSON.stringify({ "strid": idList });
    confirmAction("确认批量删除选中电子码吗？", function (d) {
        operationAction("/KeyCodeManage/DeleteAllKeyCode", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("删除成功", { icon: 1 });
                queryKeyCode();
            } else {
                $.layerAlert("删除失败", { icon: 2 });
            }

        });
    });
    return false;
}

// 删除
function singledeleted(id) {
    var para = JSON.stringify({ "id": id });
    confirmAction("确认删除吗？", function (d) {
        operationAction("/KeyCodeManage/DeletKeyCode", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("删除成功", { icon: 1 });
                queryKeyCode();
            } else {
                $.layerAlert("删除失败", { icon: 2 });
            }

        });
    });

    return false;
}

function shonephonediv(id, oldphone) {
    $("#newphone").val("");
    $("#hidCodeId").val(id);
    $("#oldphone").text(oldphone);
    layer.open({
        type: 1,
        title: '手机修改',
        area: ['360px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#divphone')
    });
}

// 修改手机
function changephone() {
    var regPhone = /^(1\d{10})$/;
    if (!regPhone.test($.trim($("#newphone").val()))) {
        $.layerAlert("请输入正确的手机号", { icon: 2 });
        return false;
    }
    var para = JSON.stringify({ "codeId": $("#hidCodeId").val(), "newphone": $.trim($("#newphone").val()) });
    confirmAction("确认修改吗？", function (d) {
        operationAction("/KeyCodeManage/UpdatePhoneByCode", para, function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                $.layerAlert("修改成功", { icon: 1 });
                queryKeyCode();

            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }

        });
    });

    return false;
}

// 显示发送失败原因
function showSendResult(id, content) {
    layer.tips(content, "#" + id);
}

//按查询条件批量导出订单
function excelKeyCode() {
    var obj = getCondition();
    obj = JSON.stringify(obj);
    location.href = "/KeyCodeManage/ExcelKeyCodeByCondition?val=" + obj;
};

// 导入订单员工框
function textChanged(txt) {
    var para = JSON.stringify({ value: $(txt).val() });
    $.ajaxExtend({
        data: para,
        url: "/KeyCodeManage/CheckedValue",
        success: function (d) {
            if (d != null && d !== "") {
                $("#dropStaffId").html(d);
            }
        }
    });
}

// 导入订单员工框
function selChanged(txt, sel) {
    var v = $(sel).find("option:selected").attr("pid");
    $(txt).val(v);
}