﻿$(function() {
    queryLog();
});
// 查询日志
function queryLog(pageIndex, pageSize) {
    pageIndex = pageIndex || 1;
    pageSize = pageSize || 10;
    myPaging({
        pageIndex: pageIndex,
        pageSize: pageSize,
        url: "/PurchaseOrder/PurchaseOrderLogs",
        methodname: queryLog
    });
}
// 分页查询
function myPaging(o) {
    var obj = $.extend(true, {
        tbody: "table#dataList tbody",
        temp: "#temp",
        pager: "#Pager",
        pageIndex: 1,
        pageSize: 10,
        data: null,
        methodname: null,
        url: null,
        success: null
    }, o);
    var para = JSON.stringify({ "orderNo": $.trim($("#orderNo").val()), "paging": getPaging(obj.pageIndex, obj.pageSize) });
    var load;
    $.ajaxExtend({
        data: para,
        url: obj.url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $(obj.tbody).html($(obj.temp).tmpl(d.Data));
            drawPagination($(obj.pager), d.Paging.PageIndex, d.Paging.PageSize, d.Paging.RowsCount, obj.methodname);
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}