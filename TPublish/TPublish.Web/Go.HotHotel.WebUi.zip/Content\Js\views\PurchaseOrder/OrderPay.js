﻿//保存线下支付信息
function insOfflinePayInfo() {
    var obj = new Object();
    obj.Account = $.trim($("#account").val());
    obj.OrderNo = $.trim($("#orderNo").val());
    if (validateInputValIsEmpty(obj.Account, $("#account"))) {
        return;
    }
    obj.PayInterfaceOrderNo = $.trim($("#capitalFlowNum").val());
    if (validateInputValIsEmpty(obj.PayInterfaceOrderNo, $("#capitalFlowNum"))) {
        return;
    }
    obj.PayRemark = $.trim($("#remarksInfo").val());
    var para = JSON.stringify({ "orderInfo": obj });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/PurchaseOrder/InsertOfflinePayInfo",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                layer.confirm("是否返回订单列表？", {
                    btn: ["是", "否"],
                    title: "保存成功",
                    icon: 1
                }, function () {
                    //window.history.back(-1);
                    window.location.href = "/PurchaseOrder/PurchaseOrderList";
                });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//验证参数
function validateInputValIsEmpty(e, f) {
    if (e === "") {
        layer.tips("不能为空", f);
        return true;
    }
    return false;
};

//显示线下支付信息
function showOfflinePay(e, d, f) {
    $("#account").val(e);
    $("#capitalFlowNum").val(d);
    $("#remarksInfo").val(f);
    layer.open({
        type: 1,
        title: "填写信息",
        area: ["460px", "auto"],
        fix: false, //不固定
        maxmin: false,
        content: $("#offline-pay-tk")
    });
};