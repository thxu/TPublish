﻿$(function() {
    var isExist = $("#hidIsExist").val();
    if (isExist === "1") {
        layer.alert("您有超时未支付的订单，请您尽快处理！");
    }
});

// 获取查询条件
function getCondition() {
    var obj = new Object();
    obj.ProductName = $.trim($("#product-name").val());
    obj.PurchaseName = $.trim($("#channel").val());
    obj.NameOrPhone = $("#name-phone").val(); 
    obj.NameOrPhone = $("#name-phone").val();
    obj.PurchaseInChargeName = $("#txtPurchaseInChargeName").val();
    var status = parseInt($.trim($("#order-state").val()));
    if (status > 0) {
        obj.OrderStatus = status;
    }
    obj.StartDate = $.trim($("#startTime").val());
    obj.EndDate = $.trim($("#endTime").val());
    obj.OrderNo = $.trim($("#orderNo").val());
    return obj;
}
// 查询
function queryCondition(pageIndex, pageSize) {
    pageIndex = pageIndex || 1;
    pageSize = pageSize || 10;
    myPaging({
        pageIndex: pageIndex,
        pageSize: pageSize,
        url: "/PurchaseOrder/QueryPurchaseOrder",
        data: getCondition(),
        methodname: queryCondition
    });
}
// 分页查询
function myPaging(o) {
    var obj = $.extend(true, {
        tbody: "table#dataList tbody",
        temp: "#temp",
        pager: "#Pager",
        pageIndex: 1,
        pageSize: 10,
        data: null,
        methodname: null,
        url: null,
        success: null
    }, o);
    var pagingCondition = getPaging(obj.pageIndex, obj.pageSize);
    var condition = obj.data;
    condition.Paging = pagingCondition;
    var para = JSON.stringify({ "condition": condition });
    var load;
    $.ajaxExtend({
        data: para,
        url: obj.url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $(obj.tbody).html($(obj.temp).tmpl(d.Data));
            drawPagination($(obj.pager), d.Paging.PageIndex, d.Paging.PageSize, d.Paging.RowsCount, obj.methodname);
            $("#poductCount").text(d.Paging.RowsCount);
            queryOrderTotal();
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

//获取订单状态Str
function getOrderState(orderState) {
    if (orderState === 1) {
        return "<span style='color:green'>待支付</span>";
    }
    if (orderState === 2) {
        return "<span style='color:#06C'>已支付</span>";
    }
    if (orderState === 3) {
        return "<span style='color:red'>已取消</span>";
    }
    if (orderState === 4) {
        return "<span style='color:#de6a14'>已挂起</span>";
    }
    return "";
}

var orderNo;
//显示线下支付信息
function showOfflinePay(e, d, f, g) {
    orderNo = g;
    $("#account").text(e);
    $("#payInterfaceOrderNo").text(d);
    $("#payRemark").text(f);
    layer.open({
        type: 1,
        title: "线下付款确认信息",
        area: ["460px", "auto"],
        fix: false, //不固定
        maxmin: false,
        content: $("#out-line-pay-sure-tk")
    });
};

//线下支付确认
function confirmOfflinePay() {
    var url = "/PurchaseOrder/ConfirmOfflinePay";
    var data = JSON.stringify({ "orderNo": orderNo });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.closeAll();
            queryCondition();
            $.layerAlert("确认成功", { icon: 1 }, function () {
                layer.closeAll();
            });
        } else {
            $.layerAlert(res.Message, { icon: 2 });
        }
    });
};

//查询订单总价
function queryOrderTotal() {
    var para = JSON.stringify({ "condition": getCondition() });
    $.ajaxExtend({
        data: para,
        url: "/PurchaseOrder/QueryPurchaseOrderTotal",
        success: function (d) {
            $("#total").show();
            $("#purchaseCount").text(d.PurchaseCount);
            $("#payCount").text(d.PaidCount);
            $("#noPayCount").text(d.UnpaidCount);
        }
    });
}

//批量导出订单
function batchExportOrder() {
    var obj = getCondition();
    obj = JSON.stringify(obj);
    location.href = "/PurchaseOrder/BatchExportPurchaseOrder?val=" + obj;
};

//导出电子码
function exportKeyCode(e) {
    location.href = "/PurchaseOrder/ExportKeyCode?val=" + e;
};

//发放电子码
function grantKeyCode(e) {
    layer.confirm("是否确认发码？", {
        btn: ["是", "否"] //按钮
    }, function () {
        var url = "/PurchaseOrder/GrantPurchaseOrderKeyCode";
        var data = JSON.stringify({ "orderNo": $.trim(e) });
        operationAction(url, data, function (res) {
            if (res.IsSucceed) {
                layer.closeAll();
                queryCondition();
                $.layerAlert("请求发码成功", { icon: 1 });
            } else {
                $.layerAlert(res.Message, { icon: 2 });
            }
        });
    });
};

//挂起电子码
function purchaseOrderHangUp(e) {
    var url = "/PurchaseOrder/PurchaseOrderHangUp";
    var data = JSON.stringify({ "orderNo": $.trim(e) });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.closeAll();
            queryCondition();
            $.layerAlert("操作成功", { icon: 1 });
        } else {
            $.layerAlert(res.Message, { icon: 2 });
        }
    });
};

//挂起电子码
function purchaseOrderHangingSolution(e) {
    var url = "/PurchaseOrder/PurchaseOrderHangingSolution";
    var data = JSON.stringify({ "orderNo": $.trim(e) });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.closeAll();
            queryCondition();
            $.layerAlert("操作成功", { icon: 1 });
        } else {
            $.layerAlert(res.Message, { icon: 2 });
        }
    });
};

// 打开更新最晚付款时间div
function showDelayDiv(orderNo) {
    $("#hidOrderNo").val(orderNo);
    $("#txtDelayDay").val(0);
    openWindowForm("推迟最晚付款时间", "#DelayDiv");
}

// 更新最晚付款时间
function delayLastPayTime() {
    var orderNo = $("#hidOrderNo").val();
    var day = parseInt($.trim($("#txtDelayDay").val()));
    var url = "/PurchaseOrder/DelayLastPayTime";
    var data = JSON.stringify({ "orderNo": orderNo, "delayDay": day });
    operationAction(url, data, function(res) {
        if (res.IsSucceed) {
            layer.closeAll();
            queryCondition();
            layer.alert("更新成功", { icon: 1 });
        } else {
            layer.alert("更新失败，" + res.Message, { icon: 2 });
        }
    });
}