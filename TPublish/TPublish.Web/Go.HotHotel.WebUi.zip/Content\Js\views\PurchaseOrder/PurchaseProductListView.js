﻿// 显示采购电子码layer
function showPurchaseByCodeDiv(name, price, stock, productId) {
    $("#txtBuyNumber").val("0");
    $("#spanProductName").text(name);
    $("#hidPurchasePrice").val(price);
    $("#spanStock").text(stock);
    $("#hidProductId").val(productId);
    openWindowForm("批量采购", "#PurchaseByCodeDiv");
}

// 批量购买电子码
function batchPurchaseByCode() {
    var number = parseInt($.trim($("#txtBuyNumber").val()));
    var productId = $("#hidProductId").val();
    var totalNumber = parseInt($("#spanStock").text());
    if (number > totalNumber) {
        layer.tips("库存不足", "#txtBuyNumber");
        return;
    }
    var obj = {
        ProductId: productId,
        PurchaseType: 1,
        KeyCodeCnt: number
    };
    var url = "/PurchaseOrder/CreatePurchaseOrder";
    var data = JSON.stringify({ "info": obj });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            if (res.Data.ShouldPay) {
                window.location.href = "/PurchaseOrder/OrderPay?orderNo=" + res.Data.OrderNo;
            } else {
                confirmAction("创单成功，确定立即发码么？", function () {
                    GrantKeyCode(res.Data.OrderNo);
                });
            }
        } else {
            layer.alert("创单失败，" + res.Message, { icon: 2 });
        }
    });
}

// 实时计算购买总价
function calTotalPrice() {
    var number = parseInt($.trim($("#txtBuyNumber").val()));
    var price = parseFloat($("#hidPurchasePrice").val());
    if (isNaN(number)) {
        number = 0;
    }
    var totalPrice = number * price;
    
    $("#spanTotalAmount").text(parseFloat(totalPrice).toFixed(2));
}

// 显示导入Excellayer
function showPurchaseByExcelDiv(productId) {
    document.myForm.fileName.value = null;
    $("#hidProductIdForExcel").val(productId);
    openWindowForm("批量采购", "#PurchaseByExcelDiv");
}

// 尝试批量导入客户（如果没有重复数据则直接创单，否则提示客户）
function tryBatchPurchaseByExcel() {
    var file = document.myForm.fileName.files[0];
    if (file === undefined) {
        layer.msg("未选择文件");
        return;
    }

    var fm = new FormData();
    fm.append("fileT", file);

    var productId = $("#hidProductIdForExcel").val();
    var url = "/PurchaseOrder/IsCustomerExist?productId=" + productId;
    var load;
    $.ajaxExtend({
        data: fm,
        url: url,
        contentType: false,
        processData: false,
        type: "POST",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (res) {
            if (res.IsSucceed) {
                if (res.Data.ShouldPay) {
                    window.location.href = "/PurchaseOrder/OrderPay?orderNo=" + res.Data.OrderNo;
                } else {
                    confirmAction("创单成功，确定立即发码么？", function () {
                        GrantKeyCode(res.Data.OrderNo);
                    });
                }
            } else {
                if (res.Message === "有重复的数据") {
                    var customerUrl = "/PurchaseOrder/ExistedCustomerView";
                    var param = {
                        strInfoList: res.Data,
                        path: res.Path,
                        productId: res.ProductId
                    }
                    post(customerUrl, param);
                } else {
                    layer.alert("创单失败，" + res.Message, { icon: 2 });
                }
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
}

// 采购确认批量导入数据
function BatchPurchaseByExcelWithConfirm(existedIdList, path, productId) {
    confirmAction("此操作会将重复的客户数据导入系统，您确认继续导入吗？", function () {
        BatchPurchaseByExcel(existedIdList, path, productId);
    });
}

// 采购确认批量导入数据
function BatchPurchaseByExcel(existedIdList, path, productId) {
    var url = "/PurchaseOrder/ContinueImportCustomerInfo";
    var data = JSON.stringify({ "strIdinfoList": existedIdList, "path": path, "productId": productId });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            if (res.Data.ShouldPay) {
                window.location.href = "/PurchaseOrder/OrderPay?orderNo=" + res.Data.OrderNo;
            }
            else {
                confirmAction("创单成功，确定立即发码么？", function() {
                    GrantKeyCode(res.Data.OrderNo);
                });
            }
        } else {
            layer.alert("创单失败，" + res.Message, { icon: 2 });
        }
    });
}

function post(url, params) {
    var temp = document.createElement("form");
    //创建form表单 
    temp.action = url;
    temp.method = "post";
    temp.style.display = "none";
    //表单样式为隐藏
    for (var item in params) {
        //初始化表单内部的控件
        //根据实际情况创建不同的标签元素 
        var opt = document.createElement("input");
        //添加input标签
        opt.type = "text";
        //类型为text 
        opt.id = item;
        //设置id属性 
        opt.name = item;
        //设置name属性 
        opt.value = params[item];
        //设置value属性
        temp.appendChild(opt);
    } document.body.appendChild(temp); temp.submit(); return temp;
}

// 发码
function GrantKeyCode(orderNo) {
    var url = "/PurchaseOrder/GrantPurchaseOrderKeyCode";
    var data = JSON.stringify({ "orderNo": orderNo });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.closeAll();
            window.location.href = "/PurchaseOrder/PurchaseOrderList";
        } else {
            $.layerAlert(res.Message, { icon: 2 });
        }
    });
}