﻿$(function () {
    queryKeyCode();
});
// 查询电子码
function queryKeyCode(pageIndex, pageSize) {
    pageIndex = pageIndex || 1;
    pageSize = pageSize || 10;
    myPaging({
        pageIndex: pageIndex,
        pageSize: pageSize,
        url: "/PurchaseOrder/PurchaseOrderCodes",
        methodname: queryKeyCode
    });
}
// 分页查询
function myPaging(o) {
    var obj = $.extend(true, {
        tbody: "table#dataList tbody",
        temp: "#temp",
        pager: "#Pager",
        pageIndex: 1,
        pageSize: 10,
        data: null,
        methodname: null,
        url: null,
        success: null
    }, o);
    var para = JSON.stringify({ "orderNo": $.trim($("#orderNo").val()), "paging": getPaging(obj.pageIndex, obj.pageSize) });
    var load;
    $.ajaxExtend({
        data: para,
        url: obj.url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $(obj.tbody).html($(obj.temp).tmpl(d.Data));
            drawPagination($(obj.pager), d.Paging.PageIndex, d.Paging.PageSize, d.Paging.RowsCount, obj.methodname);
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

function getKeyCodeStatusText(status) {
    switch (status) {
        case 10:
            return "<span class='KeyStatus' style='color: #F00'>已作废</span>";
        case 11:
            return "<span class='KeyStatus' style='color: #093'>未发放</span>";
        case 12:
            return "<span class='KeyStatus' style='color: #06C'>已发放</span>";
        case 13:
            return "<span class='KeyStatus' style='color: #de6a14'>已使用</span>";
        case 14:
            return "<span class='KeyStatus' style='color: #F00'>已挂起</span>";
        default:
            return "未知";
    }
}