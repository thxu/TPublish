﻿//$(function () {
//    layer.confirm("是否立即发码？", {
//        btn: ["是", "否"] //按钮
//    }, function () {
//        var url = "/PurchaseOrder/GrantPurchaseOrderKeyCode";
//        var data = JSON.stringify({ "orderNo": $.trim($("#orderNo").val()) });
//        operationAction(url, data, function (res) {
//            if (res.IsSucceed) {
//                layer.closeAll();
//                $.layerAlert("请求发码成功", { icon: 1 });
//            } else {
//                $.layerAlert(res.Message, { icon: 2 });
//            }
//        });
//    });
//});

function GrantKeyCode() {
    var url = "/PurchaseOrder/GrantPurchaseOrderKeyCode";
    var data = JSON.stringify({ "orderNo": $.trim($("#orderNo").val()) });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.closeAll();
            $.layerAlert("请求发码成功", { icon: 1 });
        } else {
            $.layerAlert(res.Message, { icon: 2 });
        }
    });
}