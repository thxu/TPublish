﻿$(function () {
    queryHoliday();
});

//    节假日添加
$(".addHoliday").click(function () {
    layer.open({
        type: 1,
        title: '添加节假日',
        area: ['360px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#holiday-setting-tk')
    });
});

//    节假日删除
$(".delete").click(function () {  //删除
    layer.confirm('您确定要删除该节假日吗？', {
        title: '节假日删除',
        btn: ['确定', '取消'] //按钮
    }, function () {
        layer.msg('该节假日已删除', { icon: 1 });
    });
});
//节假日新增
function saveHoliday() {
    if ($.trim($("#startTime").val()) === "") {
        $.layerAlert("请输入开始时间", { icon: 2 });
        return;
    }

    if ($.trim($("#endTime").val()) === "") {
        $.layerAlert("请输入结束时间", { icon: 2 });
        return;
    }
    if ($.trim($("#holidayName").val()) === "") {
        $.layerAlert("请输入节假日名称", { icon: 2 });
        return;
    }
    var info = {
        HolidayName: $("#holidayName").val(),
        HolidayStartTime: $("#startTime").val(),
        HolidayEndTime: $.trim($("#endTime").val())
    };
    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HolidayManage/InsertHolidayInfo",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                layer.closeAll();
                queryHoliday();
                $.layerAlert("新增成功", { icon: 1 });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
//查询节假日设置
function queryHoliday() {
    var load;
    $.ajaxExtend({
        url: "/HolidayManage/QueryHolidayInfo",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $("#dataList tbody").html($("#temp").tmpl(d));
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//获取时间yyyy年M月d日
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + "年" + (date.getMonth() + 1) + "月" + date.getDate() + "日";
};
//获取时间yyyy-MM-dd
function getDate1(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + "-" + PrefixInteger((date.getMonth() + 1), 2).toString() + "-" + PrefixInteger(date.getDate(), 2).toString();
};
//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};

var id;
//修改节假日
function updateHoliday(e, n, t, d) {
    id = e;
    $("#upHolidayName").val(n);
    $("#upStartTime").attr("value", getDate1(t));
    $("#upEndTime").attr("value", getDate1(d));
    layer.open({
        type: 1,
        title: '节假日修改',
        area: ['360px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#edit-tk')
    });
};

function updateHolidaySys() {
    if ($.trim($("#upStartTime").val()) === "") {
        $.layerAlert("请输入开始时间", { icon: 2 });
        return;
    }

    if ($.trim($("#upEndTime").val()) === "") {
        $.layerAlert("请输入结束时间", { icon: 2 });
        return;
    }
    if ($.trim($("#upHolidayName").val()) === "") {
        $.layerAlert("请输入节假日名称", { icon: 2 });
        return;
    }
    var info = {
        HolidayName: $("#upHolidayName").val(),
        HolidayStartTime: $("#upStartTime").val(),
        HolidayEndTime: $.trim($("#upEndTime").val()),
        Id: parseInt(id)
    };
    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/HolidayManage/UpdateHolidayInfo",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                layer.closeAll();
                queryHoliday();
                $.layerAlert("修改成功", { icon: 1 });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//删除节假日
function deleteHoliday(e, f) {
    confirmAction("确认删除吗？", function () {
        var para = JSON.stringify({ "id": e });
        var load;
        $.ajaxExtend({
            data: para,
            url: "/HolidayManage/DeleteHolidayInfo",
            beforeSend: function () {
                load = window.layer.load(1);
            },
            success: function (d) {
                if (d.IsSucceed) {
                    layer.closeAll();
                    queryHoliday();
                    $.layerAlert("删除成功", { icon: 1 });
                    if (f === "1") {
                        $("#weekEndBtn").show();
                    }
                } else {
                    $.layerAlert(d.Message, { icon: 2 });
                }
            },
            complete: function () {
                if (load) {
                    window.layer.close(load);
                }
            }
        });
    });
};

//添加周末
function addWeekend() {
    var load;
    $.ajaxExtend({
        url: "/HolidayManage/AddHolidayByWeekend",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                layer.closeAll();
                queryHoliday();
                $.layerAlert("添加周末成功", { icon: 1 });
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};

//隐藏添加周末按钮
function hideWeekBtn() {
    $("#weekEndBtn").hide();
};