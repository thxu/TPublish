﻿//省市联动
function provincecg(dom) {
    $(dom).next().html('<option>请选择</option>');
    $(dom).next().next().html('<option>请选择</option>');
    if ($(dom).val() !== "" && $(dom).val() !== "请选择") {
        var para = JSON.stringify({ "province": $(dom).find(":selected").val() });
        $.ajaxExtend({
            url: "/Vip/GetCity",
            data: para,
            type: "post",
            success: function(data) {

                if (data.length === 0) {
                    $(dom).next().html("<option value=''>请选择</option>");
                } else {
                    var items = "";
                   
                    items += "<option value=''>请选择</option>";
                    for (var i = 0; i < data.length; i++) {
                        items += "<option value='" + data[i].AreaId + "'>" + data[i].AreaName + "</option>";
                    }
                    $(dom).next().html(items);
                }
            }
        });
    }
}


//市区联动
function citycg(dom) {
    $(dom).next().html('<option value="">请选择</option>');
    if ($(dom).val() !== "" && $(dom).val() !== "请选择") {
        var para = JSON.stringify({ "city": $(dom).find(":selected").val() });
        $.ajaxExtend({
            url: "/Vip/GetDistrict",
            data: para,
            type: "post",
            success: function(data) {
                if (data.length == 0) {
                    $(dom).next().html("<option>请选择</option>");
                } else {
                    var items = "";
                    items += "<option>请选择</option>";
                    for (var i = 0; i < data.length; i++) {
                        items += "<option value='" + data[i].AreaId + "'>" + data[i].AreaName + "</option>";
                    }
                    $(dom).next().html(items);
                }
            }
        });
    }
}

//国家省联动
function countrycg(dom) {
    $(dom).next().html('<option value="">请选择</option>');
    if ($(dom).val() !== "" && $(dom).val() !== "请选择") {
        var para = JSON.stringify({ "country": $(dom).find(":selected").val() });
        $.ajaxExtend({
            url: "/City/GetProvince",
            data: para,
            type: "post",
            success: function (data) {
                if (data.length == 0) {
                    $(dom).next().html("<option>请选择</option>");
                } else {
                    var items = "";
                    var nextitems = "";
                    items += "<option>请选择</option>";
                    nextitems += "<option>请选择</option>";
                    for (var i = 0; i < data.length; i++) {
                        if (parseInt(data[i].AreaType) == 2) {
                            items += "<option value='" + data[i].AreaId + "'>" + data[i].AreaName + "</option>";
                        } else if (parseInt(data[i].AreaType) == 3) {
                            nextitems += "<option value='" + data[i].AreaId + "'>" + data[i].AreaName + "</option>";
                        }
                    }
                    $(dom).next().html(items);
                    $(dom).next().next().html(nextitems);
                }
            }
        });
    }
}

//获取部门
function GetSecondDepartment(dom) {
    $(dom).next().html('<option>请选择</option>');
    $(dom).next().next().html('<option>请选择</option>');
    
    if ($(dom).val() !== "" && $(dom).val() !== "请选择") {
        var para = JSON.stringify({ "deparMent": $(dom).find(":selected").val() });
        $.ajaxExtend({
            url: "/Employee/GetDownDepart",
            data: para,
            type: "post",
            success: function(data) {
                if (data.length == 0) {
                    $(dom).next().html("<option>请选择</option>");
                } else {
                    var items = "";
                    items += "<option>请选择</option>";
                    for (var i = 0; i < data.length; i++) {
                        items += "<option value='" + data[i].Id + "'>" + data[i].Name + "</option>";
                    }
                    $(dom).next().html(items);
                }
            }
        });
    }
}

//获取二级行业
function QuerySecondByFirstId(dom) {
    $(dom).next().html('<option>请选择</option>');
    $(dom).next().next().html('<option>请选择</option>');
    if ($(dom).val() != "" && $(dom).val() != "请选择") {
        var para = JSON.stringify({ "Id": $(dom).find(":selected").val() });
        $.ajaxExtend({
            url: "/BusinessManage/QuerySecondByFirstId",
            data: para,
            type: "post",
            success: function(data) {
                if (data.length == 0) {
                    $(dom).next().html("<option>请选择</option>");
                } else {
                    var items = "";
                    items += "<option>请选择</option>";
                    for (var i = 0; i < data.length; i++) {
                        items += "<option value='" + data[i].Id + "'>" + data[i].Name + "</option>";
                    }
                    $(dom).next().html(items);
                }
            }
        });
    }
}
// 查询下一级别所有公司
function getFilterShopID(dom, type) {
    $(dom).next().html('<option value="">请选择</option>');
    $(dom).next().next().html('<option value="">请选择</option>');
    if ($(dom).val() !== "" && $(dom).val() !== "请选择") {
       
        //  $(dom).next().next().html('<option></option>')
        if ($(dom).find(":selected").val() !== "") {
            var para = JSON.stringify({ "filterOfficeID": $("#FilterOfficeID").find(":selected").val(), "filterShopID": $("#FilterShopID").find(":selected").val(), "type": type });
            $.ajaxExtend({
                url: "/Contacts/GetStoreCompanyList",
                data: para,
                type: "post",
                success: function (data) {
                    if (data.length === 0) {
                        $(dom).next().html("<option value=''>请选择</option>");
                    } else {
                        var items = "";
                        items += "<option value=''>请选择</option>";
                        for (var i = 0; i < data.length; i++) {
                            items += "<option value='" + data[i].CompanyID + "'>" + data[i].CompanyName + "</option>";
                        }
                        $(dom).next().html(items);
                    }
                }
            });
        }
    }
}
