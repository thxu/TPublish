﻿function bindDateTimeByyyyyMMdd() {
    WdatePicker({ doubleCalendar: true, dateFmt: 'yyyy-MM-dd' });
}

$(function () {
    $("#CreateTimeStart").on("click", function () {
        bindDateTimeByyyyyMMdd();
    });
    $("#CreateTimeEnd").on("click", function () {
        bindDateTimeByyyyyMMdd();
    });

    $("#CntDaysStart").on("click", function () {
        bindDateTimeByyyyyMMdd();
    });
    $("#CntDaysEnd").on("click", function () {
        bindDateTimeByyyyyMMdd();
    });
    $("#txtCntDays").on("click", function () {
        bindDateTimeByyyyyMMdd();
    });
});