﻿// 打开窗口
function openWindowForm(title, id, width) {
    if (id.substring(0, 1) !== "#") {
        id = "#" + id;
    }
    width = width || "500px";
    window.layer.open({
        type: 1,
        title: title,
        area: [width, "auto"],
        fix: false,
        maxmin: false,
        content: $(id)
    });
}

// 关闭窗口
function closeWindowForm(index) {
    if (index) {
        window.layer.close(index);
    } else {
        window.layer.closeAll();
    }
}

// 清空查询条件
function clearCondition() {
    $("input[type='text']").each(function () {
        if (this.id !== "Lower" && this.id !== "Upper") {
            $(this).val("");
        }
    });
}

// 权限验证
function isAuthorization(url) {
    var result = false;
    var data = JSON.stringify({ url: url });
    $.ajaxExtend({
        data: data,
        url: "/Base/HasPermission",
        async :false,
        success: function (d) {
            if (d) {
                result = true;
            }
        },
        error: function () {
            result = false;
        }
    });
    return result;
}


// 操作函数
function operationAction(url, data, callback, error) {
    var load;
    $.ajaxExtend({
        data: data,
        url: url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (callback) {
                callback(d);
            }
        },
        error: function (e) {
            if (error) {
                error(e);
            }
            if (load) {
                window.layer.close(load);
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

// 确认函数
function confirmAction(title, sureAction, cancelAction) {
    $.layerConfirm(title, { icon: 3, title: "提示" }, function () {
        if (sureAction) {
            sureAction();
        }
    }, function () {
        if (cancelAction) {
            cancelAction();
        }
    });
}

// 成功默认提示函数
function defualtSuccessAction(d, callback) {
    if (d.IsSucceed) {
        if (callback) {
            callback();
        }
        $.layerAlert(d.Message, { icon: 1 });
    } else {
        $.layerAlert(d.Message, { icon: 2 });
    }
}

// 列子
/*
confirmAction("你确定要删除吗?", function () {
    var para = JSON.stringify({ departmentId: id });
    // 调用操作函数
    operationAction("/Department/RemoveRole", para, function (d) {
        // 调用默认函数
        defualtSuccessAction(d, function () {
            // 执行成功的函数
            closeEdit();
            initData();
        });
    });
});
*/

// 获取下拉列表的文本值
function getSelectText(id, firstText) {
    firstText = firstText || "请选择";
    var selectText = $.trim($("#" + id).find("option:selected").text());
    return selectText === firstText ? "" : selectText;
}

// 获取下拉列表的文本值
function getSelectVal(id, firstText) {
    firstText = firstText || "";
    var selectVal = $.trim($("#" + id).find("option:selected").val());
    if (selectVal === "请选择") {
        selectVal = "";
    }
    return selectVal === firstText ? "" : selectVal;
}

//获取分页信息
function getPaging(pageindex, pagesize) {
    return { "PageSize": pagesize, "PageIndex": pageindex, "GetRowsCount": true };
}

// 为空验证
function validateEmpty(o) {
    var id;
    if (o.id.substring(0, 1) !== "#") {
        id = "#" + o.id;
    } else {
        id = o.id;
    }
    if ($.trim($(id).val()) <= 0) {
        $.layerTips(o.msg, id);
        return false;
    }
    return true;
}

//为空验证弹框提示add by jianghao
function validateEmptyAlert(o) {
    var id;
    if (o.id.substring(0, 1) !== "#") {
        id = "#" + o.id;
    } else {
        id = o.id;
    }
    if ($.trim($(id).val()) <= 0) {
        $.layerAlert(o.msg, { icon: 2 });
        return false;
    }
    return true;
}
//正则表达式验证 add by jianghao
function validateReg(o) {
    var id;
    if (o.id.substring(0, 1) !== "#") {
        id = "#" + o.id;
    } else {
        id = o.id;
    }
    var reg = o.reg;
    if (!reg.test($(id).val())) {
        $.layerTips(o.msg, id);
        return false;
    }
    return true;
}
//正则表达式弹框提示add by jianghao
function validateRegAlert(o) {
    var id;
    if (o.id.substring(0, 1) !== "#") {
        id = "#" + o.id;
    } else {
        id = o.id;
    }
    var reg = o.reg;
    if (!reg.test($(id).val())) {
        $.layerAlert(o.msg, { icon: 2 });
        return false;
    }
    return true;
}


function getLogCondition() {
    var obj = new Object();
    obj.OperationUserId = $.trim($("#hidOperationUserId").val());
    return obj;
}

// 查询会员信息
function queryLogCondition(pageIndex) {

    pagingQuery(pageIndex, 4, "/Vip/LogListVal", getLogCondition(), queryLogCondition);
}

// 获取经纬度
function getAddressInfo() {
    $("#txtMapLatitude").val("");
    $("#txtMapLongitude").val("");

    var province = getSelectText("Province");
    var city = getSelectText("City");
    var district = getSelectText("District");
    var detailaddress = $("#detailaddress").val();
    var para = JSON.stringify({ "address": province + city + district + detailaddress });

    $.ajaxExtend({
        data: para,
        url: "/BusinessManage/GetAddressInfo",
        success: function (e) {
            if (e.IsSuccessed) {
                $("#txtMapLatitude").val(e.Latitude);
                $("#txtMapLongitude").val(e.Longitude);
            } else {
                $.layerConfirm("未能查询到该地址经纬度，是否跳转网站查询", { icon: 3, title: "提示" }, function () {
                    window.open("http://www.gpsspg.com/maps.htm");
                });

            }
        }
    });
}