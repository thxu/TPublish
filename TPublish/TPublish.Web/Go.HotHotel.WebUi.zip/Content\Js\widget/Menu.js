﻿$(function () {
    // 一级菜单选中
    var selectFirstMenuId = $("#firstMenu li:eq(0)").attr("id");
    $("#firstMenu li").tabControl({
        className: "active",
        cookieName: "FirstMenuId",
        isRememberState: true,
        currId: selectFirstMenuId
    });
});

// 一级菜单
function changeMenu(obj) {
    $("#firstMenu li[class='active']").attr("class", "");
    $(obj).attr("class", "active");
    var url = $(obj).attr("url");
    location.href = url;
}

function openChangePwdLayer() {
    openWindowForm("修改登录密码", "#changePwdDiv");
}

function changeLoginPwd() {
    var oldPwd = $.trim($("#txtOriginalPwd").val());
    var newPwd = $.trim($("#txtNewPwd").val());
    var newPwdConfirm = $.trim($("#txtConfirmNewPwd").val());
    if (oldPwd === '') {
        layer.alert("请输入原密码");
        return false;
    }
    if (newPwd === '') {
        layer.alert("请输入新密码");
        return false;
    }
    if (newPwd !== newPwdConfirm) {
        layer.alert("两次新密码输入不一致");
        return false;
    }
    var url = "/Home/ChangeLoginPwd";
    var data = JSON.stringify({ "oldPwd": oldPwd, "newPwd": newPwd });
    operationAction(url, data, function(res) {
        if (res.IsSucceed) {
            location.href = "/Unauthorized/LoginView";
        } else {
            layer.alert("修改失败，" + res.Message, { icon: 2 });
        }
    });
}