/**
 * booking js
 * 
 * @author homer.yang
 */
var $booking = {};
$booking.weeks_CN = ["周日","周一","周二","周三","周四","周五","周六"]
var path = "";
var dzmNum = 1;
var dayNum = 1;
$booking.loadBooking1 = function(basePath) {
	path = basePath;
	var pid = $("#pid").val();
	$booking.pid = pid;
	$.ajax({
		type : "POST",
	    dataType: "JSON",
	    url: basePath + "servlet/booking2",
	    data: {
	      action: "booking1",
	      pid: pid
	    },
	    success: function( data ) {
	      if (data.success) {
	        $(".page-header h3").text(data.product.productName);
	        $(".page-header span").text(data.product.addr?data.product.addr:"");
	        $(".lead").text(data.product.productNote);
	        
	        if(data.product.guideUrl){
	        	$("#guideUrl").html("<a href='http://"+data.product.guideUrl+"' >预约指南</a>");
	        }else{
	        	$("#guideUrl").addClass("disableHref");
	        	$("#guideUrl").html("预约指南");
	        }
	        
	        $("#ft-calendar ul").html("");
	        var lis = [];
	        if (data.product.productSpecs) {
	        	data.product.productSpecs.forEach(function(productSpec) {
		        	productSpec.specDepots.forEach(function(specDepot) {
		        		var date = specDepot.formatDate.substring(5) + "(" + $booking.weeks_CN[specDepot.week-1] +")";
		        		if(specDepot.display == 0){
			        		if ($("#ft-calendar ul").html()) {
			        			var li = $("#ft-calendar ul li[date=\""+specDepot.date+"\"]");
			        			if (li) {
			        				if (li.find("span").hasClass("booking-no")) {
			        					console.log(date + ":" + specDepot.productId + ":" + data.product.basePrice + ":" + specDepot.count);
			        					var span2 = li.find("span:eq(2)");
			        					if (specDepot.count >= 10 && specDepot.total > 0) {
			        						span2.removeClass("booking-no");
			    	        				span2.addClass("booking-yes");
			    	        				span2.text("可预约");
			    	        			} else if (specDepot.count < 10 && specDepot.count > 0 && specDepot.total > 0) {
			    	        				span2.removeClass("booking-no");
			    	        				span2.addClass("booking-yes booking-yes-color1");
			    	        				span2.text("剩"+specDepot.count);
			    	        			}
			        					
			        					if (specDepot.addPrice > 0 && specDepot.count > 0) {
			        						li.find("span:eq(1)").text("补￥" + specDepot.addPrice);
			        					}
			        				}
			        			}
			        		} else {
			        			lis.push("<li class=\"ft-calendar-li\" date=\""+specDepot.date+"\" price=\""+data.product.basePrice+"\">");
			        			lis.push("<span class=\"date\">" + date +"</span>");
			        			
			        			if (specDepot.addPrice > 0 && specDepot.count > 0) {
			        				lis.push("<span class=\"desc\">补￥" + specDepot.addPrice + "</span>");
			        			} else {
			        				lis.push("<span class=\"desc\">&nbsp;</span>");
			        			}
			        			
			        			if (specDepot.count >= 10 && specDepot.total > 0) {
			        				lis.push("<span class=\"booking-yes\">可预约</span>");
			        			} else if (specDepot.count < 10 && specDepot.count > 0 && specDepot.total > 0) {
			        				lis.push("<span class=\"booking-yes booking-yes-color1\">剩"+specDepot.count+"</span>");
			        			} else {
			        				lis.push("<span class=\"booking-no\">已约满</span>");
			        			}
			        			
			        		}
		        		}else{
		        			lis.push("<li class=\"ft-calendar-li\" date=\""+specDepot.date+"\" price=\""+data.product.basePrice+"\">");
		        			lis.push("<span class=\"date\">" + date +"</span>");
		        			lis.push("<span class=\"desc\">&nbsp;</span>");
		        			lis.push("<span class=\"booking-no\"></span>");
		        		}
		        		
		        			
		        	});
		        	
		        	if ($("#ft-calendar ul").html()) {
	        			
	        		} else {
	        			$("#ft-calendar ul").html(lis.join(""));
	        		}
		        	
		        });
	      	}
	        $booking.init1();
	      } else {
	    	  $("#ft-calendar").html("<p>" + data.error + "</p>");
	      }
	      $("#loading_warp").hide();
	    }
	});
}


$booking.loadBooking2 = function(basePath) {
	var pid = $("#pid").val();
	var selectDate = $("#selectDate").val();
	$booking.pid = pid;
	$booking.selectDate = selectDate;
	$.ajax({
		type : "POST",
	    dataType: "JSON",
	    url: basePath + "servlet/booking2",
	    data: {
	      action: "booking2",
	      pid: pid,
	      selectDate: selectDate
	    },
	    success: function( data ) {
	      console.log(data);
	      if (data.success) {
	    	$(".page-header h3").text(data.product.productName);
		    $(".page-header span").text(data.product.addr?data.product.addr:"");
	        //$(".lead").text(data.product.productNote);
		    $(".panel-title").text($(".panel-title").text() + " 游玩日期[ " + selectDate + " ]");
	        
	        var tbodys = [];
	    
	        data.product.productSpecs.forEach(function(productSpec) {
	        	if (productSpec.specDepots) {
	        		
	        		console.log(productSpec.name);
	        		
	        		var specDepot = productSpec.specDepots[0];
	        		var count = specDepot.count;
	        		if (!count) {count = 0;}
	        		
	        		tbodys.push("<tr id=\""+productSpec.id+"\" buchaPrice=\""+ specDepot.addPrice +"\">");
	        		
	        		var productSpecNote = "";
	        		if (productSpec.typeNote) {
	        			productSpecNote = "<div style=\"font-size: 12px; color: gray;\">"+productSpec.typeNote+"</div>"
	        		}
	        		tbodys.push("<td>"+productSpec.name+productSpecNote+"</td>");
	        		
	        		
	        		if (count > 10 && specDepot.total > 0) {
	        			tbodys.push("<td>&gt;10</td>");
	        		} else if (count <= 10 && count > 0 && specDepot.total > 0) {
	        			tbodys.push("<td>"+count+"</td>");
	        		} else {
	        			tbodys.push("<td class=\"booking-no\">满</td>");
	        		}
	        		tbodys.push("<td>"+specDepot.addPrice+"元</td>");
	        		if (count > 0 && specDepot.total > 0) {
	        			tbodys.push("<td><a class=\"btn btn-success\" href=\"javascript:void(0)\" onclick=\"$booking.selectProductSpec(this);\">预约</a></td>");
	        		} else {
	        			tbodys.push("<td>&nbsp;</td>");
	        		}
	        		
	        	}
	        	
	        });
	        
	        $("tbody").html(tbodys.join(""));
	        
	      }
	    }
	});
}


$booking.loadBooking3 = function(basePath) {
	var pid = $("#pid").val();
	var selectDate = $("#selectDate").val();
	var productSpecId = $("#productSpecId").val();
	var buchaPrice = $("#buchaPrice").val();
	$booking.pid = pid;
	$booking.selectDate = selectDate;
	$booking.productSpecId = productSpecId;
	$booking.buchaPrice = buchaPrice;
	$booking.basePath = basePath;
	$.ajax({
		type : "POST",
	    dataType: "JSON",
	    url: basePath + "servlet/booking2",
	    data: {
	      action: "booking3",
	      pid: pid,
	      selectDate: selectDate,
	      productSpecId: productSpecId
	    },
	    success: function( data ) {
	      if (data.success) {
	    	  $(".page-header h3").text(data.product.productName);
		      $(".page-header span").text(data.product.addr?data.product.addr:"");
		      //$(".lead").text(data.product.productNote);
		      //游玩日期
		      $("#playDate").val(selectDate);
		      //获取当前选择的日期后两天的库存
		      $.ajax({
		    	  type : "POST",
				  dataType: "JSON",
				  url: basePath + "servlet/booking2",
				  data: {
					  action: "selectProductSpecByPlayDate",
					  pid: pid,
					  selectDate: selectDate,
					  productSpecId: productSpecId
				  },
				  success: function( data ) {
					  if(data.success){
						  var rearSpecDepots = data.specDepots;
						  //判断当前日期后两天的库存情况决定预约天数可选几天
						  if(rearSpecDepots.length > 0){
							  var bookingNum = $("#bookingNum");
							  if(bookingNum){
								  var date1count;
								  var date2count;
								  if(rearSpecDepots.length == 1){
									  date1count = rearSpecDepots[0].count;
									  $booking.rearSpecDepot1 = rearSpecDepots[0];
								  }
								  if(rearSpecDepots.length == 2){
									  date1count = rearSpecDepots[0].count;
									  date2count = rearSpecDepots[1].count;
									  $booking.rearSpecDepot1 = rearSpecDepots[0];
									  $booking.rearSpecDepot2 = rearSpecDepots[1];
								  }

								  var count = 1;
								  if (date1count > 0){
									  count += 1;
								  }
								  if(date1count > 0 && date2count > 0){
									  count += 1;
								  }
								  
								  var bookingNumItems = [];
								  for (var i = 1; i <= count; i++) {
									  bookingNumItems.push("<option>"+i+"</option>");
								  }
								  bookingNum.html(bookingNumItems.join(""));
							  }
						  }else{
							  $("#bookingNum").html("<option>1</option>");
						  }
					  }
				  }
		  	  });
		      
		      //直通车抢购商品预约天数限定一天
		      if(pid == "100283" || pid == "100277" || pid == "100261" || pid == "100250" || pid == "100226"){
		    	  $("#bookingNum").attr("readonly","readonly");
		    	  $("#bookingNum").attr("disabled","disabled");
		      }
		      $booking.productSpec = data.product.productSpecs[0];
		      $("#selectProductSpecName").val($booking.productSpec.name);
		      //实名制产品,姓名和手机输入框只读
		      if(data.product.realName == 1){
		    	  $("#inputName").prop("placeholder","输入正确券号后自动填充购买人姓名");
		    	  $("#inputPhone").prop("placeholder","输入正确券号后自动填充购买人手机");
    			  $("#inputName").prop("readonly","readonly");
    			  $("#inputPhone").prop("readonly","readonly");
		      }
	    	  if ($booking.productSpec.specDepots) {
	    		  $booking.product = data.product;
	    		  var selectProductSpecNum = $("#selectProductSpecNum");
	    		  
	    		  if (selectProductSpecNum) {
	    			  var selectProductSpecNumItems = [];
	    			  
	    			  var count = $booking.productSpec.specDepots[0].count;
	    			  if (count > 8) {count=8;}
	    			  
	    			  for (var i = 1; i <= count; i++) {
	    				  selectProductSpecNumItems.push("<option>"+i+"</option>");
	    			  }
	    			  selectProductSpecNum.html(selectProductSpecNumItems.join(""));
	    		  }
	    	  }
	      }
	    }
	});
	
	//门票选择
	if(pid == '100034' || pid == '100289'){
		if(productSpecId == "100442" || productSpecId == "100443"){
			$("#note").html("套票已包含2人茶溪谷+大峡谷门票，2份早餐，如需加订门票，每张电子券可加购各类门票各3张，如需加早，则在前台自理.");
		}
		$("#ticket").show();
	}
}

$booking.loadBooking4 = function(basePath) {
	$booking.basePath = basePath;
	
	var pid = $("#pid").val();
	var bookRecordId = $("#bookRecordId").val();
	$.ajax({
		type : "POST",
		dataType: "JSON",
		url: basePath + "servlet/booking2",
		data: {
			action: "booking4",
			pid: pid,
			bookRecordId: bookRecordId
		},
		success: function( data ) {
			console.log(data);
			if (data.success) {
				//判断补差方式
				if(data.productSpec.addType == 0 || (data.productSpec.addType == 1 && data.bookRecord.addTotalPrice == 0)){
					$("#panelTitle").text("预约成功");
					$("#bookSuccessHint").text(data.product.bookSuccessHint);
				}else if(data.productSpec.addType == 1 && data.bookRecord.addTotalPrice > 0){
					$("#panelTitle").text("支付差价");
//					预约日期：2017年06月21日
//					姓名：杨峰
//					补差价：100元
//					请在30分钟内完成支付，过时本次预约将会自动取消。若没有支付成功，您可以通过以下方法继续完成预约：
//					（1）30分钟内再次进入预约页面，点击左上角“我的订单”，凭电子码或手机号查找订单继续完成支付；
//					（2）凭原来的电子码重新进行预约。原来的预约将会自动取消，（如果使用了多个电子码）同一预约的其它电子码将会恢复有效；
					var expenseDate = data.bookRecord.expenseDate;
					var expensedateArr = expenseDate.split(",");
					var newExpensedate = "";
					if (expensedateArr.length == 1) {
						// 新格式的消费时间
						newExpensedate += expenseDate.substring(0, 4) + "-" + expenseDate.substring(4, 6) + "-" + expenseDate.substring(6);
					}else if (expensedateArr.length == 2){
						newExpensedate += expensedateArr[0].substring(0, 4) + "-" + expensedateArr[0].substring(4, 6) + "-" + expensedateArr[0].substring(6);
						newExpensedate += ","+expensedateArr[1].substring(0, 4) + "-" + expensedateArr[1].substring(4, 6) + "-" + expensedateArr[1].substring(6);
					}else if (expensedateArr.length == 3) {
						newExpensedate += expensedateArr[0].substring(0, 4) + "-" + expensedateArr[0].substring(4, 6) + "-" + expensedateArr[0].substring(6);
						newExpensedate += ","+expensedateArr[1].substring(0, 4) + "-" + expensedateArr[1].substring(4, 6) + "-" + expensedateArr[1].substring(6);
						newExpensedate += ","+expensedateArr[2].substring(0, 4) + "-" + expensedateArr[2].substring(4, 6) + "-" + expensedateArr[2].substring(6);
					}
					var tips = "预约日期： " + newExpensedate + "<br>"
							 + "姓名： " + data.bookRecord.names + "<br>"
							 + "补差价： " + data.bookRecord.addTotalPrice + "元<br>"
							 + "请在30分钟内完成支付，过时本次预约将会自动取消。若没有支付成功，您可以通过以下方法继续完成预约：<br>"
							 + "（1）30分钟内再次进入预约页面，点击左上角“我的订单”，凭电子码或手机号查找订单继续完成支付；<br>"
							 + "（2）凭原来的电子码重新进行预约。原来的预约将会自动取消，（如果使用了多个电子码）同一预约的其它电子码将会恢复有效；";
					$("#tips").html(tips);
					if (data.bookRecord.state == 2) {
						var ua = navigator.userAgent;
						var ua_Lower = ua.toLowerCase();
						// micromessenger
						if (ua_Lower.indexOf('micromessenger') > 0) {
							// wechat browser
							$("#wechat-pay").attr("style", "display: inline;");
						}
						// 判断是支付宝 APP 内
						else if (ua_Lower.indexOf('alipayclient') > 0) {
							$("#alipay-mobile-pay").attr("style", "display: inline;");
						} 
						// 手机浏览器
						else if (ua_Lower.indexOf('mobile') > 0) {
							$("#wechat-qr-pay").attr("style", "display: inline;");
							$("#alipay-qr-pay").attr("style", "display: inline;");
							$("#alipay-mobile-pay").attr("style", "display: inline;");
						} else {
							$("#wechat-qr-pay").attr("style", "display: inline;");
							$("#alipay-qr-pay").attr("style", "display: inline;");
							$("#alipay-mobile-pay").attr("style", "display: inline;");
						}
					} else {
						$("#no-pay").show();
					}
				}
				
				$("#loading_warp").hide();
			}
		}
	});
}

$booking.checkSubOrder = function() {
	var tickets = [];
	var consumeCodeIds = [];
	var name = $("#inputName").val();
	var phone = $("#inputPhone").val();
	var productNum = $("#selectProductSpecNum").val();
	var note = $("#inputNote").val();
	//入住日期
	var bookingDay = $("#playDate").val().replace(/\s/g, "");
	var bookingTotalNum = $("#selectProductSpecNum").val() * $("#bookingNum").val();
	
	var checkTickets = true;
	if ($("#selectProductSpecNum")) {
		var inputTickets = $("#inputTickets input");
		for (var i = 0; i < bookingTotalNum; i++) {
			var inputTicket = inputTickets[i];
			var ticketValue = $(inputTicket).val();
			var dataId = $(inputTicket).attr("data-id");
			if (ticketValue && dataId) {
				tickets.push(ticketValue);
				consumeCodeIds.push(dataId);
			} else {
				checkTickets = false; break;
			}
		}
		
	}
	if (!checkTickets) {
		$(".alert").text("请输入有效的券号！");
		$(".alert").show();
		return;
	} else if (!name) {
		$(".alert").text("请输入姓名！");
		$(".alert").show();
		return;
	} else if (!phone) {
		$(".alert").text("请输入手机！");
		$(".alert").show();
		return;
	} else if (!/^(13|14|15|17|18)\d{9}$/.test(phone)) {
		$(".alert").text("请输入正确的手机！");
		$(".alert").show();
		return;
	} else {
		$(".alert").hide();
		$booking.subData = {};
		$booking.subData.action = "booking";
		$booking.subData.ticketNum = tickets.join(",");
		$booking.subData.consumeCodeIds = consumeCodeIds.join(",");
		$booking.subData.buchaPrice = $booking.buchaPrice;
		$booking.subData.date = bookingDay;
		$booking.subData.name = name;
		$booking.subData.phone = phone;
		$booking.subData.productSpecId = $booking.productSpecId;
		$booking.subData.pid = $booking.pid;
		$booking.subData.remark = note;
	}
	
	var orderDetails = [];
	
	orderDetails.push("<tr><td nowrap>姓名</td><td>" + name + "</td></tr>");
	orderDetails.push("<tr><td nowrap>手机</td><td>" + phone + "</td></tr>");
	orderDetails.push("<tr><td nowrap>预约产品</td><td>" + $booking.product.productName + "</td></tr>");
	
	var productSpecNote = "";
	if ($booking.productSpec.typeNote) {
		productSpecNote = "<div style=\"font-size: 12px; color: gray;\">"+$booking.productSpec.typeNote+"</div>";
	}
	orderDetails.push("<tr><td nowrap>预约型号</td><td>" + $booking.productSpec.name + productSpecNote + "</td></tr>");
	
	orderDetails.push("<tr><td nowrap>预约数量</td><td>" + bookingTotalNum + "</td></tr>");
	
	var playDate = "";
	var addPrice = "";
	var ticketPriceStr = ""; //门票加收
	var ticketNote = ""; //门票备注
	var ticketTotalPrice = 0; //门票加收金额
	
	//获取门票相关数据
	$(".ticket_num").each(function(){
		if($(this).hasClass("a")){
			var currentNum = parseInt($(this).val());
			var ticketName = $(this).parent().parent().prev().text();
			var ticketPrice = $(this).parent().parent().prev().data("price");
			if(currentNum > 0){
				ticketPriceStr += "<br>" + ticketName + " : <span style=\"color: #d9534f;\">" +  ticketPrice + "</span>元&nbsp;x&nbsp;" + currentNum;
				ticketNote += ticketName + " : " + ticketPrice +"元 * " + currentNum + " ; ";
				ticketTotalPrice += currentNum * parseFloat(ticketPrice);
			}
		}else if($(this).hasClass("b")){
			var currentNum = parseInt($(this).val());
			var ticketName = $(this).parent().parent().prev().text();
			var ticketPrice = $(this).parent().parent().prev().data("price");
			if(currentNum > 0){
				ticketPriceStr += "<br>" + ticketName + " : <span style=\"color: #d9534f;\">" +  ticketPrice + "</span>元&nbsp;x&nbsp;" + currentNum;
				ticketNote += ticketName + " : " + ticketPrice +"元 * " + currentNum + " ; ";
				ticketTotalPrice += currentNum * parseFloat(ticketPrice);
			}
		}else if($(this).hasClass("c")){
			var currentNum = parseInt($(this).val());
			var ticketName = $(this).parent().parent().prev().text();
			var ticketPrice = $(this).parent().parent().prev().data("price");
			if(currentNum > 0){
				ticketPriceStr += "<br>" + ticketName + " : <span style=\"color: #d9534f;\">" +  ticketPrice + "</span>元&nbsp;x&nbsp;" + currentNum;
				ticketNote += ticketName + " : " + ticketPrice +"元 * " + currentNum + " ; ";
				ticketTotalPrice += currentNum * parseFloat(ticketPrice);
			}
		}
	});
	
	$booking.subData.ticketTotalPrice = ticketTotalPrice.toFixed(2);
	$booking.subData.ticketNote = ticketNote;
	
	var roomAddPrice = 0;
	if($("#bookingNum").val() == 1){
		roomAddPrice = $booking.subData.buchaPrice;
		playDate = "";
		playDate = "<tr><td nowrap>预约日期</td><td><h4 style=\"color: #d9534f;\">" + $booking.productSpec.specDepots[0].formatDate + " " + $booking.weeks_CN[$booking.productSpec.specDepots[0].week-1] + "</h4></td></tr>";
		if ($booking.subData.buchaPrice > 0) {
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		
	}else if($("#bookingNum").val() == 2){
		roomAddPrice = $booking.subData.buchaPrice + $booking.rearSpecDepot1.addPrice;
		playDate = "";
		playDate = "<tr><td nowrap>预约日期</td><td><h4 style=\"color: #d9534f;\">" + $booking.productSpec.specDepots[0].formatDate + " " + $booking.weeks_CN[$booking.productSpec.specDepots[0].week-1] + 
				   "</h4><h4 style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.formatDate + " " + $booking.weeks_CN[$booking.rearSpecDepot1.week-1] + "</h4></td></tr>";
		if ($booking.subData.buchaPrice > 0 && $booking.rearSpecDepot1.addPrice > 0) {
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
						"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if($booking.subData.buchaPrice > 0 && !($booking.rearSpecDepot1.addPrice > 0)){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if(!($booking.subData.buchaPrice > 0) && $booking.rearSpecDepot1.addPrice > 0){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td>" +
					"<td><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		
	}else if($("#bookingNum").val() == 3){
		roomAddPrice = $booking.subData.buchaPrice + $booking.rearSpecDepot1.addPrice + $booking.rearSpecDepot2.addPrice;
		playDate = "";
		playDate = "<tr><td nowrap>预约日期</td><td><h4 style=\"color: #d9534f;\">" + $booking.productSpec.specDepots[0].formatDate + " " + $booking.weeks_CN[$booking.productSpec.specDepots[0].week-1] + "</h4>"+
				   "<h4 style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.formatDate + " " + $booking.weeks_CN[$booking.rearSpecDepot1.week-1] + "</h4>"+
				   "<h4 style=\"color: #d9534f;\">" + $booking.rearSpecDepot2.formatDate + " " + $booking.weeks_CN[$booking.rearSpecDepot2.week-1] + "</h4></td></tr>";
		console.log(playDate);
		if ($booking.subData.buchaPrice > 0 && $booking.rearSpecDepot1.addPrice > 0 && $booking.rearSpecDepot2.addPrice > 0) {
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
						"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
						"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot2.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if($booking.subData.buchaPrice > 0 && $booking.rearSpecDepot1.addPrice > 0 && !($booking.rearSpecDepot2.addPrice > 0)){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
						"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if($booking.subData.buchaPrice > 0 && !($booking.rearSpecDepot1.addPrice > 0) && $booking.rearSpecDepot2.addPrice > 0){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
			"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot2.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if($booking.subData.buchaPrice > 0 && !($booking.rearSpecDepot1.addPrice > 0) && !($booking.rearSpecDepot2.addPrice > 0)){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.buchaPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if(!($booking.subData.buchaPrice > 0) && $booking.rearSpecDepot1.addPrice > 0 && $booking.rearSpecDepot2.addPrice > 0){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + 
			"<br><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot2.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if(!($booking.subData.buchaPrice > 0) && $booking.rearSpecDepot1.addPrice > 0 && !($booking.rearSpecDepot2.addPrice > 0)){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot1.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		if(!($booking.subData.buchaPrice > 0) && !($booking.rearSpecDepot1.addPrice > 0) && $booking.rearSpecDepot2.addPrice > 0){
			addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td><span style=\"color: #d9534f;\">" + $booking.rearSpecDepot2.addPrice + "</span>元&nbsp;x&nbsp;" + productNum + ticketPriceStr + "</td></tr>";
		}
		
	}
	//房型无加收
	if(addPrice == ""){
		addPrice += "<tr><td nowrap>"+($booking.productSpec.addType == 0 ? "前台加收" : "在线加收")+"</td><td>" + ticketPriceStr + "</td></tr>";
	}
	orderDetails.push(playDate);
	orderDetails.push(addPrice);
	
	var totalAddPrice = parseFloat(roomAddPrice) + parseFloat(ticketTotalPrice);
	if(totalAddPrice > 0){
		//orderDetails.push("<tr><td nowrap>加收合计</td><td><span style=\"color: #d9534f;\">" + totalAddPrice.toFixed(2) + "</span>元</td></tr>");
	}
	
	if (note) {
		orderDetails.push("<tr><td nowrap>备注</td><td>" + note + "</td></tr>");
	}
	
	
	$("#orderDetailModal table tbody").html(orderDetails.join(""));
	
	$("#orderDetailModal").modal("show");
}

$(function(){
	$('#bookingButton').on('click', function () {
		var $btn = $(this).button('loading');
		$.ajax({
			type : "POST",
		    dataType: "JSON",
		    url: $booking.basePath + "servlet/booking2",
		    data: $booking.subData,
		    success: function( data ) {
		        $btn.button('reset');
		        console.log(data);
		        if (data.success) {
		        	
		    	    if (data.successUrl) {
		    		    location.href = data.successUrl;
		    	    } else {
		    	        var ua = navigator.userAgent;
					    var ua_Lower = ua.toLowerCase();
					    console.log(ua_Lower);
					    // micromessenger:判断是否是微信浏览器
					    // micromessenger:判断是否是微信浏览器
//					    if (ua_Lower.indexOf('micromessenger') > 0) {
//						    var url = $booking.basePath + "booking2-4.jsp?pid=" + $booking.pid + "&bookRecordId=" + data.bookRecordId;
//						    console.log(url);
//						    url = "http://dzm2.32888.net/yy/booking2-4.jsp?pid=100034&bookRecordId=Y000120170714172300000007";
//						    var redirectUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?response_type=code&scope=snsapi_base&state=STATE';
//						    redirectUrl += '&appid='+$("#appId").val();
//						    redirectUrl += '&redirect_uri='+encodeURIComponent(url);
//						    console.log(redirectUrl + '#wechat_redirect');
//						    window.location = redirectUrl + '#wechat_redirect';
//					    } else if (ua_Lower.indexOf('alipayclient') > 0 || ua_Lower.indexOf('mobile')) {
//					    	// 判断是手机浏览器或者是支付宝 APP内
//						    location.href = $booking.basePath + "booking2-4.jsp?pid=" + $booking.pid + "&bookRecordId=" + data.bookRecordId;
//					    } else {
//						    location.href = $booking.basePath + "booking2-4.jsp?pid=" + $booking.pid + "&bookRecordId=" + data.bookRecordId;
//					    }
					    
					    if (ua_Lower.indexOf('alipayclient') > 0 || ua_Lower.indexOf('mobile')) {
					    	// 判断是手机浏览器或者是支付宝 APP内
						    location.href = $booking.basePath + "booking2-4.jsp?pid=" + $booking.pid + "&bookRecordId=" + data.bookRecordId;
					    } else {
						    location.href = $booking.basePath + "booking2-4.jsp?pid=" + $booking.pid + "&bookRecordId=" + data.bookRecordId;
					    }
		    	    }
		        } else {
		    	    if (!data.error) {data.error = "预约失败，请稍后重试。";}
		    	    $("#orderDetailModal").modal("hide");
		    	    $(".alert").text(data.error);
		  		    $(".alert").show();
		        }
		    }
		});
	})
});


$booking.selectProductSpec = function(obj) {
	var tr = $(obj).parent().parent();
	$booking.productSpecId = tr.attr("id");
	$booking.buchaPrice = tr.attr("buchaPrice");
	//获取房型判断是否需要弹出提示框
	$.ajax({
		type : "POST",
	    dataType: "JSON",
	    url: path + "servlet/booking2",
	    data: {
	    	action:"getProductSpecById",
	    	productSpecId:$booking.productSpecId
	    },
	    success: function(data) {
	    	var productSpec = data.productSpec;
	    	console.log(productSpec);
	    	if(productSpec.prompt){
	    		//弹出提示框
	    		$("#prompt").html(productSpec.prompt);
	    		$("#promptDetailModal").modal("show");
	    	}else{
	    		location.href = "booking2-3.jsp?pid="+$booking.pid+"&selectDate="+$booking.selectDate+"&productSpecId="+$booking.productSpecId + "&buchaPrice="+$booking.buchaPrice;
	    	}
	    }
	});
}

$(function(){
	//再选一次
	$("#againBtn").click(function(){
		$("#promptDetailModal").modal("hide");
	});
	//继续
	$("#continueBtn").click(function(){
		location.href = "booking2-3.jsp?pid="+$booking.pid+"&selectDate="+$booking.selectDate+"&productSpecId="+$booking.productSpecId + "&buchaPrice="+$booking.buchaPrice;
	});
	
	//可选门票数量:3*电子码数量
	var effectiveNumA = 3 * dzmNum;
	var effectiveNumB = 3 * dzmNum;
	var effectiveNumC = 3 * dzmNum;
	
	$("#selectProductSpecNum").change(function(){
		$(".ticket_num").val("0");
		dzmNum = $(this).val();
		dayNum = $("#bookingNum").val();
	});
	
	$("#bookingNum").change(function(){
		$(".ticket_num").val("0");
		dayNum = $(this).val();
		dzmNum = $("#selectProductSpecNum").val();
	});
	//门票数量减少按钮
	$(".btn_reduce").click(function(){
		if($(this).hasClass("a")){
			console.log("A-");
			var current = $(this).parent().next();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			if(num && num > 0 ){
				current.val(num - 1);
			}
		}else if($(this).hasClass("b")){
			console.log("B-");
			var current = $(this).parent().next();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			if(num && num > 0 ){
				current.val(num - 1);
			}
		}else if($(this).hasClass("c")){
			console.log("C-");
			var current = $(this).parent().next();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			if(num && num > 0 ){
				current.val(num - 1);
			}
		}
	});
	
	//门票数量增加按钮
	$(".btn_increase").click(function(){
		if($(this).hasClass("a")){
			console.log("A+");
			var current = $(this).parent().prev();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			console.log((parseInt(brotherNum) + parseInt(num)));
			if((parseInt(brotherNum) + parseInt(num) + 1) <= (3 * dzmNum * dayNum)){
				current.val(parseInt(num) + 1);
			}
		}else if($(this).hasClass("b")){
			console.log("B+");
			var current = $(this).parent().prev();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			
			if((parseInt(brotherNum) + parseInt(num) + 1) <= (3 * dzmNum * dayNum)){
				current.val(parseInt(num) + 1);
			}
		}else if($(this).hasClass("c")){
			console.log("C+");
			var current = $(this).parent().prev();
			var brotherId = "";
			if(current.prop("id").indexOf("1") > -1){
				brotherId = current.prop("id").replace("1","2");
			}else{
				brotherId = current.prop("id").replace("2","1");
			}
			var brotherNum = $("#"+brotherId).val();
			var num = current.val();
			
			if((parseInt(brotherNum) + parseInt(num) + 1) <= (3 * dzmNum * dayNum)){
				current.val(parseInt(num) + 1);
			}
		}
	});
	
	//不允许手动输入
	$(".ticket_num").prop("readonly","readonly");
	
	
	
});

//预约数量改变
$booking.selectProductSpecNumChange = function(obj) {
	var productNum = $(obj).val();
	var dayNum = $("#bookingNum").val();
	productNum = productNum * dayNum;
	
	for (var i = 1; i <= productNum; i++) {
		$("#inputTicket"+i).parent().parent().show();
	}
	for (var i = parseInt(productNum) + 1; i <= 12; i++) {
		$("#inputTicket"+i).parent().parent().hide();
	}
}

//预约天数改变
$booking.bookingNumChange = function(obj){
	var dayNum = parseInt($(obj).val());
	var selectProductSpecNum = $("#selectProductSpecNum");
	//当前日期后两天库存
	var rearSpecDepots = $booking.rearSpecDepots;
	var rearSpecDepot1 = $booking.rearSpecDepot1;
	var rearSpecDepot2 = $booking.rearSpecDepot2;
	var count0 = $booking.productSpec.specDepots[0].count;
	var count1;
	var count2;
	var count = count0;
	var selectDate = $booking.productSpec.specDepots[0].date;
	if (selectProductSpecNum) {
		var selectProductSpecNumItems = [];
		if(rearSpecDepot1){
			count1 = rearSpecDepot1.count;
		}
		if(rearSpecDepot2){
			count1 = rearSpecDepot1.count;
			count2 = rearSpecDepot2.count;
		}
		if (dayNum == 2) {
			console.log(rearSpecDepot1);
			$("#playDate").val(selectDate + " , " + rearSpecDepot1.date);
			if(count1){
				if(count0 >= count1){
					count = count1;
				}
			}
			if(count > 4){
				count = 4;
			}
		}else if(dayNum == 3){
			$("#playDate").val(selectDate + " , " + rearSpecDepot1.date + " , " + rearSpecDepot2.date);
			if(count1 && count2){
				if(count0 <= count1){
					count = count0;
				}else{
					count = count1;
				}
				if(count > count2){
					count = count2;
				}
			}
			if(count > 4){
				 count = 4;
			 }
		}else{
			$("#playDate").val(selectDate)
			count = count0
			if(count > 8){
				count = 8;
			}
		}
		for (var i = 1; i <= count; i++) {
			  selectProductSpecNumItems.push("<option>"+i+"</option>");
		}
		selectProductSpecNum.html(selectProductSpecNumItems.join(""));
		
		var productNum = $("#selectProductSpecNum").val() * dayNum;
		
		//电子码输入框
		for (var i = 1; i <= productNum; i++) {
			$("#inputTicket"+i).parent().parent().show();
		}
		for (var i = parseInt(productNum) + 1; i <= 12; i++) {
			$("#inputTicket"+i).parent().parent().hide();
		}
	}
	
}


$booking.init1 = function() {
	$("#ft-calendar ul li").mouseover(function() {
		if ($(this).find("span:eq(2)").hasClass("booking-yes")) {
			$(this).addClass("ft-calendar-li-selected");
		}
	});
	$("#ft-calendar ul li").mouseout(function() {
		if (!$(this).attr("selected")) {
			$(this).removeClass("ft-calendar-li-selected");
		}
	});
	
	
	
	
	$("#ft-calendar ul li").mousedown(function() {
		if ($(this).find("span:eq(2)").hasClass("booking-yes")) {
			$("#ft-calendar ul li").removeClass("ft-calendar-li-selected");
			$("#ft-calendar ul li").removeAttr("selected");
			$(this).attr("selected", true);
			$(this).addClass("ft-calendar-li-selected");
			
			location.href = "booking2-2.jsp?pid="+$booking.pid+"&selectDate="+$(this).attr("date");
		}
	});
}