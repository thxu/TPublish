﻿$(function () {
    query();
});

function query(pageIndx, pageSize) {
    var logType = $("#hidLogType").val();
    var objId = $("#hidObjId").val();
    var url = "/Home/QueryLogByCondition";
    var data = {
        LogType: logType,
        ObjectId: objId
    };
    pagingQuery(pageIndx, pageSize, url, data, query);
}