﻿function weekConvert(e) {
    if (e === 1) {
        return "星期一";
    }
    else if (e === 2) {
        return "星期二";
    }
    else if (e === 3) {
        return "星期三";
    }
    else if (e === 4) {
        return "星期四";
    }
    else if (e === 5) {
        return "星期五";
    }
    else if (e === 6) {
        return "星期六";
    }
    else if (e === 7) {
        return "星期天";
    }

    return "";
}

function UpdateReleaseStockParam() {
    if ($.trim($("#dropReleaseStartWeek").val()) === "") {
        $.layerAlert("请选择释放启动星期", { icon: 2 });
        return false;
    }

    if ($.trim($("#dropSecondReleaseStartWeek").val()) === "") {
        $.layerAlert("请选择第二释放启动星期", { icon: 2 });
        return false;
    }

    if ($.trim($("#txtReleaseHourTime").val()) === "") {
        $.layerAlert("释放储备库存启动时分秒不能为空", { icon: 2 });
        return false;
    }


    var dateStar = new Date($("#SpecialReleaseStartTime").val());
    var dateEnd = new Date($("#SpecialReleaseEndTime").val());
    if (dateStar > dateEnd) {
        $.layerAlert("指定开始时间不能大于结束时间", { icon: 2 });
        return false;
    }

    var releaseTime = "";
    $("input[name='ReleaseTime']").each(function () {
        if (this.checked) {
            releaseTime += $(this).val() + "/";
        }
    });
    releaseTime = releaseTime.substr(0, releaseTime.length - 1);

    var secondReleaseTime = "";
    $("input[name='SecondReleaseTime']").each(function () {
        if (this.checked) {
            secondReleaseTime += $(this).val() + "/";
        }
    });
    secondReleaseTime = secondReleaseTime.substr(0, secondReleaseTime.length - 1);

    if (releaseTime === "" || secondReleaseTime === "") {
        $.layerAlert("请至少选择一个星期日期", { icon: 2 });
        return false;
    }
    var param = {
        Id: $.trim($("#hidId").val()),
        ReleaseStartWeek: $.trim($("#dropReleaseStartWeek").val()),
        ReleaseTime: releaseTime,
        SecondReleaseStartWeek: $.trim($("#dropSecondReleaseStartWeek").val()),
        SecondReleaseTime: secondReleaseTime,
        ReleaseHourTime: $.trim($("#txtReleaseHourTime").val()),
        IsAutoRealse: $("input[name='IsAutoRealse']").is(':checked'),
        IsReleaseStock: $("input[name='IsReleaseStock']").is(':checked'),
        SpecialReleaseStartTime: $.trim($("#SpecialReleaseStartTime").val()),
        SpecialReleaseEndTime: $.trim($("#SpecialReleaseEndTime").val()),
        BusinessId: $("#hidBusinessId").val()
};

    var para = JSON.stringify({ "param": param });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/ReleaseStockParam/UpdateReleaseStockParam",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("保存成功！", { icon: 1 }, function () {
                });
            } else {
                $.layerAlert(d.Message == null ? "保存失败" : d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}