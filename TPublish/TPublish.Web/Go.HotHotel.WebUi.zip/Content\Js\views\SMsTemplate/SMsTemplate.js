﻿// 条件
function getCondition() {
    var obj = new Object();
    obj.BusinessName = $.trim($("#txtBusinessName").val());
    obj.TemplateName = $.trim($("#txtTemplateName").val());
    obj.RecordedStatus = $.trim($("#dropRecordedStatus").val());
    obj.TemplateType = $.trim($("#dropTemplateType").val());
    return obj;
}

// 查询会员信息
function querySmsTemplate(pageIndex, pageSize) {
    pagingQuery(pageIndex, pageSize, "/SMsTemplate/SMsTemplateListVal", getCondition(), querySmsTemplate);
}

function getTemplateType(templateType) {
    if (templateType === 1) {
        return "待支付短信";
    }
    else if (templateType === 2) {
        return "订单支付成功短信";
    }
    else if (templateType === 3) {
        return "电子码短信";
    }
    else if (templateType === 4) {
        return "预约短信";
    }
    else if (templateType === 5) {
        return "预约确认短信";
    }
    else if (templateType === 6) {
        return "取消订单短信";
    }
    return "未知";
}

function getRecordedStatus(recordedStatus) {
    if (recordedStatus === 1) {
        return "未备案";
    }
    else if (recordedStatus === 2) {
        return "<span style='color:green'>已经备案</span>";
    }
    return "未知";
}

// 短信模版div
function showTemplatediv(id) {
    var title = id === "" ? "添加短信模版" : "修改短信模版";
    $("#hidTemplateId").val("");
    $("#txtdivTemplateName").val("");
    $("#txtdivTemplateContent").val("");
    $("#dropdivBusinessName option").removeAttr("selected");
    $("#dropdivTemplateType option").removeAttr("selected");
    $("#dropdivBusinessName").prop("disabled", false);
    $("#dropdivTemplateType").prop("disabled", false);
    if (id !== "") {
        $("#hidTemplateId").val(id);
        $("#dropdivBusinessName").prop("disabled", true);
        $("#dropdivTemplateType").prop("disabled", true);
        var para = JSON.stringify({ "id": id });
        $.ajaxExtend({
            data: para,
            url: "/SMsTemplate/QueryMessageTemplateById",
            success: function (data) {
                if (data !== null && data != undefined) {
                    console.log(data);
                    $("#dropdivBusinessName option[value='" + data.BusinessId + "']").prop("selected", true);
                    $("#dropdivTemplateType option[value='" + data.TemplateType + "']").prop("selected", true);
                    $("#txtdivTemplateName").val(data.TemplateName);
                    $("#txtdivTemplateContent").val(data.TemplateContent);
                    $("#leftlength").text(70 - data.TemplateContent.length);
                }
            }
        });
    }

    $("#aKeyCode").hide();
    $("#aName").hide();
    $("#aEndDate").hide();

    layer.open({
        type: 1,
        title: title,
        area: ['400px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#divTemplatediv')
    });
}

// 保存短信模版
function saveSmsTemplate() {
    if ($.trim($("#dropdivBusinessName").val()) === "") {
        $.layerAlert("请选择酒店", { icon: 2 });
        return false;
    }

    if ($.trim($("#dropdivTemplateType").val()) === "") {
        $.layerAlert("请选择业务类型", { icon: 2 });
        return false;
    }

    if ($.trim($("#txtdivTemplateName").val()) === "") {
        $.layerAlert("模版标题不能为空", { icon: 2 });
        return false;
    }
    if ($.trim($("#txtdivTemplateContent").val()) === "") {
        $.layerAlert("短信模板内容不能为空", { icon: 2 });
        return false;
    }
    var url;
    if ($("#hidTemplateId").val() === "") {
        url = "/SMsTemplate/AddMsgTemplate";
    } else {
        url = "/SMsTemplate/UpdateMsgTemplate";
    }

    var info = {
        Id: $("#hidTemplateId").val(),
        BusinessId: $.trim($("#dropdivBusinessName").val()),
        TemplateName: $.trim($("#txtdivTemplateName").val()),
        TemplateType: $.trim($("#dropdivTemplateType").val()),
        TemplateContent:  $.trim($("#txtdivTemplateContent").val()),
        StoreId: 0,
        ProductId:"",
        SpecificationsId:0,
    };

    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                $.layerAlert("操作成功", { icon: 1 });
                querySmsTemplate();
            } else {
                $.layerAlert(d.Message == null ? "操作失败" : d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

// 通配符附加方法
function movedata(data) {
    var templateContent = $("#txtdivTemplateContent").val();
    templateContent = templateContent + data;

    var newtemplateContent = templateContent.replace(/(【电子码】|【姓名】|【有效期】|【入住时间】|【预约链接】|【预约时间】)/g, "");
    if (newtemplateContent.length > 70) {
        $.layerAlert("输入此字符长度将超过70，不可再输入字符");
        return false;
    }
    $("#txtdivTemplateContent").val(templateContent);
    $("#leftlength").text(70 - newtemplateContent.length);
    return false;
}

// 短信类型切换后更换通配符
function changeWildcards() {
    var type = $.trim($("#dropdivTemplateType").val());
    switch (type) {
        case "3":
            $("#aKeyCode").show();
            $("#aURL").show();
            $("#aName").hide();
            $("#aEndDate").hide();
            $("#aCheckInDate").hide();
            $("#ayyTime").hide();
            return;
        case "4":
            $("#aKeyCode").hide();
            $("#aURL").hide();
            $("#aName").show();
            $("#aEndDate").hide();
            $("#aCheckInDate").hide();
            $("#ayyTime").show();
            return;
        case "5":
            $("#aKeyCode").hide();
            $("#aURL").hide();
            $("#aName").show();
            $("#aEndDate").show();
            $("#aCheckInDate").hide();
            $("#ayyTime").hide();
            return;
        case "6":
            $("#aKeyCode").show();
            $("#aURL").hide();
            $("#aName").hide();
            $("#aEndDate").hide();
            $("#aCheckInDate").show();
            $("#ayyTime").hide();
            return;
        default:
            $("#aKeyCode").hide();
            $("#aURL").hide();
            $("#aName").hide();
            $("#aEndDate").hide();
            $("#aCheckInDate").hide();
            $("#ayyTime").hide();
            return;
    }
}

function datalength(obj) {
    var data = $(obj).val();
    var newdata = data.replace(/(【电子码】|【姓名】|【有效期】|【入住时间】)/g, "");
    $("#leftlength").text(70 - newdata.length);
}

// 设未默认
function setdefault(id) {
    var para = JSON.stringify({ "id": id });
    operationAction("/SMsTemplate/SetDefaultTemplate", para, function (d) {
        if (d.IsSucceed === true) {
            $.layerAlert("操作成功", { icon: 1 });
            querySmsTemplate();
        } else {
            $.layerAlert("操作失败", { icon: 2 });
        }

    });

    return false;
}

// 备案
function recorded(id) {
    var para = JSON.stringify({ "id": id, "recordedStatus": 2 });
    operationAction("/SMsTemplate/UpdateRecordStatus", para, function (d) {
        if (d.IsSucceed === true) {
            $.layerAlert("操作成功", { icon: 1 });
            querySmsTemplate();
        } else {
            $.layerAlert(d.Message == null ? "操作失败" : d.Message, { icon: 2 });
        }

    });

    return false;
}

// 未备案
function disrecorded(id) {
    var para = JSON.stringify({ "id": id, "recordedStatus": 1 });
    operationAction("/SMsTemplate/UpdateRecordStatus", para, function (d) {
        if (d.IsSucceed === true) {
            $.layerAlert("操作成功", { icon: 1 });
            querySmsTemplate();
        } else {
            $.layerAlert("操作失败", { icon: 2 });
        }

    });

    return false;
}

// 删除
function deletedTemplate(id) {
    var para = JSON.stringify({ "id": id });
    confirmAction("确认删除该短信模版吗？", function () {
        operationAction("/SMsTemplate/DelMsgTemplate", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("删除成功", { icon: 1 });
                querySmsTemplate();
            } else {
                $.layerAlert("删除失败", { icon: 2 });
            }

        });
    });

    return false;
}

// 发送测试短信
function sendtextSms() {
    var phone = $("#txttestphone").val();
    var regPhone = /^(1\d{10})$/;
    if (!regPhone.test(phone)) {
        $.layerAlert("请输入正确的手机号", { icon: 2 });
        return false;
    }

    var smsContent = $("#txtdivTemplateContent").val();
    var para = JSON.stringify({ "phone": phone, "smsContent": smsContent });
    operationAction("/SMsTemplate/AsyncAddSendSmsLog", para, function (d) {
        if (d.IsSucceed === true) {
            $.layerAlert("发送完毕，请等待接收", { icon: 1 });
            querySmsTemplate();
        } else {
            $.layerAlert(d.Message == null ? "发送失败" : d.Message, { icon: 2 });
        }

    });
}