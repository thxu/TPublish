﻿// 条件
function getCondition() {
    var obj = new Object();
    obj.BusinessName = $.trim($("#txtBusinessName").val());
    obj.LoginId = $.trim($("#txtLoginId").val());
    obj.BusinesslTel = $.trim($("#txtBusinesslTel").val());
    return obj;
}

// 查询会员信息
function queryPurchaseAccount(pageIndex, pageSize) {
    pagingQuery(pageIndex, pageSize, "/PurchaseAccount/PurchaseAccountVal", getCondition(), queryPurchaseAccount);
}

function getBusinessState(businessState) {
    if (businessState === 1) {
        return "<span style='color:red'>禁用</span>";
    }
    else if (businessState === 2) {
        return "<span style='color:green'>启用</span>";
    }

    return "";

}

// 添加
function addPurchaseAccount() {
    var ck = checkBaseparameters();
    if (!ck) return ck;
    var delayDay = $.trim($("#txtDelayDay").val());
    if ($("input[name='PayType']:checked").val() === "1") {
        delayDay = 0;
    }
    var info = {
        BusinessName: $.trim($("#txtBusinessName").val()),
        LoginId: $.trim($("#txtLoginId").val()),
        LoginPwd: $.trim($("#txtLoginPwd").val()),
        BusinesslTel: $.trim($("#txtBusinesslTel").val()),
        PayType: $("input[name='PayType']:checked").val(),
        DelayDay: delayDay,
        Remark: $.trim($("#txtRemark").val()),
        PurchaseRebate: $.trim($("#txtPurchaseRebate").val()),
        PurchaseInChargeId: $.trim($("#txtPurchaseInCharge").val()),
        PurchaseInChargeName: $.trim($("#txtPurchaseInCharge").find("option:selected").text())

    };

    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/PurchaseAccount/AddPurchase",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("账号添加成功！", { icon: 1 }, function () {
                    $("#btnback").click();
                });

            } else {
                $.layerAlert(d.Message == null ? "添加失败" : d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;

}

// 修改
function UpdatePurchaseAccount() {
    var ck = checkBaseparameters();
    if (!ck) return ck;

    var delayDay = $.trim($("#txtDelayDay").val());
    if ($("input[name='PayType']:checked").val() === "1") {
        delayDay = 0;
    }
    var info = {
        BusinessId: $.trim($("#hidBusinessId").val()),
        BusinessName: $.trim($("#txtBusinessName").val()),
        LoginId: $.trim($("#txtLoginId").val()),
        LoginPwd: $.trim($("#txtLoginPwd").val()),
        BusinesslTel: $.trim($("#txtBusinesslTel").val()),
        PayType: $("input[name='PayType']:checked").val(),
        DelayDay: delayDay,
        Remark: $.trim($("#txtRemark").val()),
        PurchaseRebate: $.trim($("#txtPurchaseRebate").val()),
        PurchaseInChargeId: $.trim($("#txtPurchaseInCharge").val()),
        PurchaseInChargeName: $.trim($("#txtPurchaseInCharge").find("option:selected").text())
    };

    var para = JSON.stringify({ "info": info });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/PurchaseAccount/UpdatePurchase",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("账号修改成功！", { icon: 1 }, function () {
                    $("#btnback").click();
                });
            } else {
                $.layerAlert(d.Message == null ? "修改失败" : d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;

}

function checkBaseparameters() {
    if ($.trim($("#txtBusinessName").val()) === "") {
        $.layerAlert("渠道名称不能为空", { icon: 2 });
        return false;
    }

    if ($.trim($("#txtBusinesslTel").val()) === "") {
        $.layerAlert("被注册人联系方式不能为空", { icon: 2 });
        return false;
    }

    var regPhone = /^(1\d{10})$/;
    if (!regPhone.test($.trim($("#txtBusinesslTel").val()))) {
        $.layerAlert("请输入正确的手机号", { icon: 2 });
        return false;
    }

    if ($("input[name='PayType']:checked").val() === "2" && $.trim($("#txtDelayDay").val()) === "") {
        $.layerAlert("可延期付款天数不能为空", { icon: 2 });
        return false;
    }

    if ($("input[name='PayType']:checked").val() === "2" && parseInt($.trim($("#txtDelayDay").val())) === 0) {
        $.layerAlert("可延期付款天数不能为零", { icon: 2 });
        return false;
    }

    var rebate = parseFloat($.trim($("#txtPurchaseRebate").val()));
    if (rebate < -100 || rebate > 100) {
        $.layerAlert("贴返点必须在正负100之间", { icon: 2 });
        return false;
    }

    return true;
}

// 启用
function enablePurchaseAccount(businessId) {
    var para = JSON.stringify({ "businessId": businessId });
    confirmAction("确认启用吗？", function () {
        operationAction("/PurchaseAccount/EnablePurchaseAccount", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("启用成功", { icon: 1 });
                queryPurchaseAccount();
            } else {
                $.layerAlert("启用失败", { icon: 2 });
            }

        });
    });

    return false;
}

// 禁用
function disEnablePurchaseAccount(businessId) {
    var para = JSON.stringify({ "businessId": businessId });
    confirmAction("确认禁用吗？", function () {
        operationAction("/PurchaseAccount/DisEnablePurchaseAccount", para, function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("禁用成功", { icon: 1 });
                queryPurchaseAccount();
            } else {
                $.layerAlert("禁用失败", { icon: 2 });
            }

        });
    });

    return false;
}
