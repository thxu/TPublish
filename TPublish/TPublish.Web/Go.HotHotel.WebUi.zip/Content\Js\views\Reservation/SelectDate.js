﻿$(function () {
    if ($.trim($("#dataList").html()) !== "") {
        $("#loading_warp").hide();
        return;
    }
    var para = JSON.stringify({ "businessId": parseInt($.trim($("#businesslId").val())) });
    $.ajaxExtend({
        data: para,
        url: "/Reservation/SelectDateProducts",
        success: function (d) {
            if (d != null) {
                $("#startTime").text(d.StartTime);
                $("#endTime").text(d.EndTime);
                for (var i = 0; i < d.ProductsInfo.length; i++) {
                    d.ProductsInfo[i].ReservationDate = d.ProductsInfo[i].ReservationDate.replace('-', '/')
                        .replace('-', '/');
                }
                $("#dataList").html($("#temp").tmpl(d.ProductsInfo));
            }
        },
        complete: function () {
            $("#loading_warp").hide();
        }
    });

    setHeight(".attentionBtn", ".attentionBtn", 0.4378);
});

function setHeight(area, referenceDom, percent)
{
    var wid = $(referenceDom).width();
    var height = wid * percent;
    $(area).height(height);
}
function removeModal(e) {
    var ev = e || window.event || arguments.callee.caller.arguments[0];
    var $target = $(ev.target || ev.currentTarget || ev.srcElement);
    var clickParAttr = $target.parents("div[data-modelFlag=true]").attr("data-modelFlag");
    if ($target.attr("data-modelFlag") !== "true" && clickParAttr !== "true") {
        showToggleModal(".attentionModal", false);
    }
}
function showToggleModal(area, flag) {
    if (flag) {
        $(area).removeClass("domHide");
        return;
    }
    $(area).addClass("domHide");
}



//获取时间yyyy-MM-dd
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear().toString() + PrefixInteger((date.getMonth() + 1), 2).toString() + PrefixInteger(date.getDate(), 2).toString();
};

//获取时间MM-dd
function getDateByMMdd(d) {
    var date = new Date(d);
    return PrefixInteger((date.getMonth() + 1), 2)
    + "-" + PrefixInteger(date.getDate(), 2);
};

//获取星期
function getWeek(d) {
    var week = new Date(d).getDay();
    if (week === 0) {
        return "日";
    } else if (week === 1) {
        return "一";
    } else if (week === 2) {
        return "二";
    } else if (week === 3) {
        return "三";
    } else if (week === 4) {
        return "四";
    } else if (week === 5) {
        return "五";
    } else if (week === 6) {
        return "六";
    }
    return "";
};

//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};