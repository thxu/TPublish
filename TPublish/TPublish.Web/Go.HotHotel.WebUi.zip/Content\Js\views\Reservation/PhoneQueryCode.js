﻿function getValidateCode() {
    var date = new Date();
    var validateCode = document.getElementById("validateCode");
    validateCode.src = "/Reservation/GetValidateCode?v=" + date;
}


function queryPhone() {
    var phone = $("#txtphone").val();
    var validatecode = $("#txtcode").val();
    var regPhone = /^(1[35784]\d{9})$/;
    if (!regPhone.test($.trim(phone))) {
        $.layerAlert("请输入正确的手机号", { icon: 2 });
        return false;
    }
    // 验证验证码
    var para = JSON.stringify({ "validatecode": validatecode });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/ValidateValidateCode",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                window.location.href = "/Reservation/QueryKeyCodeByPhone?phone=" + phone;
                return false;
            } else {
                var meg = d.Message || "验证码异常";
                $.layerAlert(meg, { icon: 2 });
                return false;
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}

// 补发短信
function sendSms(id, username, userphone, ordernumber, endtime, businessid) {
    var obj = new Object();
    obj.Id = id;
    obj.UserName = username;
    obj.UserPhone = userphone;
    obj.OrderNumber = ordernumber;
    obj.EndTime = endtime;
    obj.BusinessId = businessid;
    confirmAction("确认发送吗？", function () {
        var para = JSON.stringify({ "coderInfo": obj });
        operationAction("/Reservation/SendSms", para, function (result) {
            if (result.IsSucceed) {
                layer.alert("发送成功", { icon: 1, title: "提示" });
            } else {
                var meg = result.Message || "发送失败";
                layer.alert(meg, { icon: 2, title: "提示" });
            }
        });
    });
}

// 加载更多
function loadmoreCode(phone) {
    var pageindex = parseInt($("#hidpageIndex").val()) + 1;
    $("#hidpageIndex").val(pageindex);
    var para = JSON.stringify({ "phone": phone, "pageindex": pageindex });
    operationAction("/Reservation/QueryKeyCodeByPhoneAjax", para, function (data) {
        if (data != null) {
            if (data.length > 0) {
                var str = "";
                for (var i = 0; i < data.length; i++) {

                    str += ("<div class=\"row cell-box\"><div class=\"col-xs-8\"><div class=\"title\">" + data[i].BusinessName + "</div><div class=\"code\">" + data[i].KeyCode + "</div><div class=\"state\"> <span>状态:&nbsp;</span>");
                    if (data[i].KeyStatus === 10) {
                        str += ("<span class='KeyStatus' style='color: #F00'>作废</span>");
                    } else if (data[i].KeyStatus === 11) {
                        str += ("<span class='KeyStatus' style='color: #093'>未发</span>");
                    }
                    else if (data[i].KeyStatus === 12) {
                        str += ("<span class='KeyStatus' style='color: #06C'>已发</span>");
                    }
                    else if (data[i].KeyStatus === 13) {
                        str += ("<span class='KeyStatus' style='color: #de6a14'>已用</span>");
                    }
                    else if (data[i].KeyStatus === 14) {
                        str += ("<span class='KeyStatus' style='color: #F00'>挂起</span>");
                }
                    str += ("</div></div>");
                    // 补发
                    if (data[i].KeyStatus === 11 || data[i].KeyStatus === 12) {
                        str += ("<div class=\"col-xs-4 text-right \"><button class=\"reissue\" onclick=\"sendSms('" + data[i].Id + "', '" + data[i].UserName + "', '" + data[i].UserPhone + "', '" + data[i].OrderNumber + "', '" + data[i].EndTime + "', '" + data[i].BusinessId + "');\">补发</button></div>");
                }
                    str += ("</div>");
            }
                $("#divfirstcode").append(str);
            } else {
                layer.alert("没有更多了", {
                        icon: 3, title: "提示"
                });
        }
        } else {
            layer.alert("加载失败", {
                    icon: 1, title: "提示"
            });
    }
    });
}

