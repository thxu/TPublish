﻿var hid = parseInt($.trim($("#hid").val()));
var pid = $.trim($("#pid").val());
var isReserve = false;
if ($(".hideType").val() === "1") {
    isReserve = true;
}

//提交
function checkSubOrder() {
    var order = new Object();
    var playDateList = [];
    var keyCodeAry = [];
    var bookInfo = [];
    var subPids = [];
    var subPidStr = $.trim($("#subPid").val());
    if (subPidStr !== "") {
        var subPidSz = subPidStr.split("_");
        for (var i = 0; i < subPidSz.length; i++) {
            var subPid = new Object();
            subPid.ProductId = subPidSz[i].split("x")[0];
            subPid.Count = subPidSz[i].split("x")[1];
            subPids.push(subPid);
        }
    }

    $("#dataList .checked").each(function () {
        playDateList.push($(this).attr("date"));
        var obj = {};
        obj.PlayDate = $(this).attr("date");
        var bookProduct = [];
        var bookobj = {};
        bookobj.ProdcutId = pid;
        bookobj.Num = $("#selectProductSpecNum").val();
        bookProduct.push(bookobj);
        obj.BookProduct = bookProduct;
        bookInfo.push(obj);
    });
    var isErro = false;
    $("#inputTickets .form-group").each(function () {
        var code = $.trim($(this).find("input").val());
        if (code === "") {
            isErro = true;
            layer.tips("请输入电子码", $(this).find("input"), { tips: 1 });
            return false;
        }
        keyCodeAry.push(code);
        return true;
    });
    if (isErro)
        return;
    if (isRepeat(keyCodeAry)) {
        layer.msg("电子码重复");
        return;
    }
    order.ProductId = pid;
    order.BusinessId = hid;
    order.PlayDates = $.trim($(".playDateClass").val());
    order.UserName = $.trim($("#inputName").val());
    if (!checkName(order.UserName)) {
        layer.tips("姓名格式错误", $("#inputName"), { tips: 1 });
        return;
    }
    order.UserTel = $.trim($("#inputPhone").val());
    if (!checkMobile(order.UserTel)) {
        layer.tips("手机号格式错误", $("#inputPhone"), { tips: 1 });
        return;
    }
    order.BuyerRemark = $.trim($("#inputNote").val());
    order.PayType = 1;
    order.PlayDateList = playDateList;
    order.KeyCodeList = keyCodeAry;
    order.BookInfo = bookInfo;
    order.OrderAmount = $("#decimals").text();
    order.IsReserve = isReserve;

    //执行创单
    var para = JSON.stringify({ "orderInfo": order, "subPid": subPids, "subPidStr": subPidStr });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/CreatOrder",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            debugger;
            if (!d.IsSucceed) {
                layer.alert(d.Message, { icon: 2, title: "提示" });
            } else {
                if (!d.IsPay) {
                    window.location.href = "/Reservation/ReservationSuccese?businessId=" + hid;
                    return;
                }
                layer.closeAll("tips");
                if (d.IsWxWeb) {
                    if (d.IsAfreshPay) {
                        //layer.confirm("你有待支付的订单,请继续支付", { icon: 3, title: "提示", btn: ["支付", "取消"] }, function () {
                        //    tenpayHandler(d);
                        //});
                        layer.confirm("您有重复的预约未支付订单，</br>需要取消后重新预订。", { icon: 3, title: "提示", btn: ["确认取消"] }, function (index) {
                            cancelOrder(d.OrderNumber, index);
                        });
                    } else {
                        tenpayHandler(d);
                    }
                } else {
                    $("#paySucese").attr("onclick", "IsPaySuccese('" + d.OrderNumber + "');");
                    $("#refPay").attr("onclick", "window.location.href ='" + d.PayUrl + "'");
                    if (d.IsAfreshPay) {
                        //layer.confirm("你有待支付的订单,请继续支付", { icon: 3, title: "提示", btn: ["支付", "取消"] }, function (index) {
                        //    setTimeout("window.layer.open({ type: 1, title: '', area: ['80%', 'auto'], fix: false, maxmin: false, content: $('#validatePay') })", 3000);
                        //    window.location.href = d.PayUrl;
                        //    layer.close(index);
                        //});
                        layer.confirm("您有重复的预约未支付订单，</br>需要取消后重新预订。", { icon: 3, title: "提示", btn: ["确认取消"] }, function (index) {
                            cancelOrder(d.OrderNumber, index);
                        });
                    } else {
                        setTimeout("window.layer.open({ type: 1, title: '', area: ['80%', 'auto'], fix: false, maxmin: false, content: $('#validatePay') })", 3000);
                        window.location.href = d.PayUrl;
                    }
                }
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
//取消订单
function cancelOrder(orderNo, index) {
    var url = "/Reservation/CalcelOrderByUser";
    var data = JSON.stringify({ "orderNo": orderNo });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            layer.msg("取消成功");
            layer.close(index);
        } else {
            $.layerAlert("取消失败", { icon: 2 });
        }
    });
}

//验证电子码是否重复
function isRepeat(arr) {
    var hash = {};
    for (var i in arr) {
        if (arr.hasOwnProperty(i)) {
            if (hash[arr[i]])
                return true;
            hash[arr[i]] = true;
        }
    }
    return false;
}
// 日期，在原有日期基础上，增加days天数
function addDate(d, days) {
    var date = new Date(d);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + "-" + getFormatDate(month) + "-" + getFormatDate(day);
};
function getFormatDate(arg) {
    if (arg == undefined || arg === "") {
        return "";
    }
    var re = arg + "";
    if (re.length < 2) {
        re = "0" + re;
    }
    return re;
};
//验证手机号码
function checkMobile(str) {
    var re = /^1\d{10}$/;
    if (re.test(str)) {
        return true;
    } else {
        return false;
    }
};
function validatePhone(e) {
    if (!checkMobile($.trim($(e).val()))) {
        layer.tips("手机号格式错误", $(e), { tips: 1 });
        return;
    } else {
        layer.closeAll("tips");
    }
};
//验证名字
function checkName(str) {
    var re = /[\d]/g;
    if (!re.test(str) && str.length > 1) {
        return true;
    } else {
        return false;
    }
};
function validateName(e) {
    if (!checkName($.trim($(e).val()))) {
        layer.tips("姓名格式错误", $(e), { tips: 1 });
        return;
    } else {
        layer.closeAll("tips");
    }
};
//验证电子码
function checkConsumeCode(e) {
    var keyCode = $.trim($(e).val());
    var para = JSON.stringify({ "keyCode": keyCode, "businessId": hid });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/ValidateKeyCode",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (!d.IsSucceed) {
                layer.tips(d.Message, $(e), { tips: 1 });
            } else {
                layer.closeAll("tips");
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
//IsPaySuccese 是否支付成功
function IsPaySuccese(e) {
    var para = JSON.stringify({ "orderNumber": e });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/OrderIsPaySuccese",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (!d.IsSuccess) {
                layer.confirm("订单未支付？", {
                    title: "提示",
                    btn: ["我已支付", "取消支付"] //按钮
                }, function () {
                    layer.close(layer.index);
                    IsPaySuccese(e);
                    return false;
                }, function () {
                    window.location.href = "/Reservation/ReservationErro?businessId=" + hid;
                    return false;
                });
            } else {
                window.location.href = "/Reservation/ReservationSuccese?businessId=" + hid;
                return false;
            }
            return false;
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
var dataJson;
function tenpayHandler(parameters) {
    dataJson = parameters;
    if (typeof window.WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
            document.addEventListener("WeixinJSBridgeReady", onBridgeReady, false);
        } else if (document.attachEvent) {
            document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
    } else {
        onBridgeReady();
    }
}

// 微信唤醒
function onBridgeReady() {
    window.WeixinJSBridge.invoke(
        "getBrandWCPayRequest", {
            "appId": dataJson.Appid,     //公众号名称，由商户传入     
            "timeStamp": dataJson.Timestamp,         //时间戳，自1970年以来的秒数     
            "nonceStr": dataJson.NonceStr, //随机串     
            "package": dataJson.Package,
            "signType": dataJson.SignType,         //微信签名方式：     
            "paySign": dataJson.Sign //微信签名 
        },
        function (res) {
            // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。 
            if (res.err_msg === "get_brand_wcpay_request:ok") {
                //window.layer.msg("支付成功");
                window.location.href = "/Reservation/ReservationSuccese?businessId=" + hid;
            }
            else if (res.err_msg === "get_brand_wcpay_request:cancel") { // 支付取消
                window.layer.msg("支付取消");
            }
            else {
                //window.layer.msg("支付失败");
                alert(JSON.stringify(res));
                //window.location.href = "/Reservation/ReservationErro?businessId=" + hid;
            }
        }
    );
}

//选择日期
function selectDt(e) {
    if ($(e).hasClass("checked")) {
        $(e).removeClass("checked");
    } else {
        $(e).addClass("checked");
    }
    var minNumber = 0;
    $("#dataList .checked").each(function (e) {
        var number = parseInt($.trim($(this).attr("room")));
        if (e === 0) {
            minNumber = number;
        } else if (number < minNumber) {
            minNumber = number;
        }
    });
    var innerHtml = "";
    for (var i = 1; i < minNumber + 1; i++) {
        innerHtml += "<option value='" + i + "'>" + i + "</option>";
    }
    var nub = parseInt($("#selectProductSpecNum").val());
    $("#selectProductSpecNum").html(innerHtml);
    var maxindex = parseInt($("#selectProductSpecNum").find("option:last").val());
    if (maxindex < nub) {
        $("#selectProductSpecNum").val("1");
    } else {
        $("#selectProductSpecNum").val(nub);
    }
    selectProductSpecNumChange();
};

var startRow = 3;
var endRow = 4;
//更多
function moreDt() {
    var obj = new Object();
    obj.StartRow = startRow;
    obj.EndRow = endRow;
    obj.SubPid = $.trim($("#subPid").val());
    obj.StartDate = $.trim($("#startDate").val());
    obj.ProductId = pid;
    obj.BusinessId = hid;
    var para = JSON.stringify({
        "condition": obj
    });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/QueryMoreDate",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $("#moreId").remove();
            for (var item in d) {
                if (d.hasOwnProperty(item)) {
                    var date = d[item].ReservationDate.toString().replace('-', '/').replace('-', '/');
                    if (isReserve) {
                        if (d[item].ReserveAddMoney > 0) {
                            $("#dataList").append($.format($("#dateHtml").html(), getDate(date), getDateByMMdd(date), getWeek(date), d[item].ReserveAddMoney, d[item].ReserveProductNums));
                        } else {
                            $("#dataList").append($.format($("#dateHtml").html(), getDate(date), getDateByMMdd(date), getWeek(date), "&nbsp;", d[item].ReserveProductNums));
                        }
                    } else {
                        if (d[item].AddMoney > 0) {
                            $("#dataList").append($.format($("#dateHtml").html(), getDate(date), getDateByMMdd(date), getWeek(date), d[item].AddMoney, d[item].ProductNums));
                        } else {
                            $("#dataList").append($.format($("#dateHtml").html(), getDate(date), getDateByMMdd(date), getWeek(date), "&nbsp;", d[item].ProductNums));
                        }
                    }
                }
            }
            if (d.length > 0) {
                startRow += 7;
                $("#dataList").append("<span id='moreId' style='padding: 5px;' onclick='moreDt();'>更多></span>");
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};
//数量改变
function selectProductSpecNumChange() {
    var people = parseInt($.trim($("#selectProductSpecNum").val()));
    var days = parseInt($("#dataList .checked").length);
    var number = people * days;
    var innerHtml = "";
    for (var i = 0; i < number; i++) {
        innerHtml += "<div class=\"form-group\"><label for=\"inputTicket11\"class=\"col-sm-2 control-label\">电子码</label><div class=\"col-sm-9\"><input type=\"text\"class=\"form-control\"id=\"inputTicket11\"onblur=\"checkConsumeCode(this)\"placeholder=\"请输入电子码\"></div></div>";
    }
    $("#inputTickets").html(innerHtml);
    setDetail();
};

//获取时间yyyy-MM-dd
function getDate(d) {
    var date = new Date(d);
    return date.getFullYear() + "-" + PrefixInteger((date.getMonth() + 1), 2) + "-" + PrefixInteger(date.getDate(), 2).toString();
};

//获取时间MM-dd
function getDateByMMdd(d) {
    var date = new Date(d);
    return PrefixInteger((date.getMonth() + 1), 2)
    + "-" + PrefixInteger(date.getDate(), 2);
};

//获取星期
function getWeek(d) {
    var week = new Date(d).getDay();
    if (week === 0) {
        return "日";
    } else if (week === 1) {
        return "一";
    } else if (week === 2) {
        return "二";
    } else if (week === 3) {
        return "三";
    } else if (week === 4) {
        return "四";
    } else if (week === 5) {
        return "五";
    } else if (week === 6) {
        return "六";
    }
    return "";
};

//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};

//订单明细
function setDetail() {
    var dateCount = $("#dataList .checked").length;
    var number = dateCount * parseInt($("#selectProductSpecNum").val());
    $("#mCount").text(number);
    $(".sCount").each(function () {
        $(this).text(parseInt($.trim($(this).attr("count"))) * dateCount);
    });
    SetMoney();
};

//设置总额
function SetMoney() {
    var order = new Object();
    var playDateList = [];

    var subPids = [];
    var subPidStr = $.trim($("#subPid").val());
    if (subPidStr !== "") {
        var subPidSz = subPidStr.split("_");
        for (var i = 0; i < subPidSz.length; i++) {
            var subPid = new Object();
            subPid.ProductId = subPidSz[i].split("x")[0];
            subPid.Count = subPidSz[i].split("x")[1];
            subPids.push(subPid);
        }
    }

    $("#dataList .checked").each(function () {
        playDateList.push($(this).attr("date"));
    });
    order.ProductId = pid;
    order.BusinessId = hid;
    order.PlayDateList = playDateList;
    order.PeopleCount = parseInt($.trim($("#selectProductSpecNum").val()));

    //查询总计
    var para = JSON.stringify({ "orderInfo": order, "subPid": subPids, "isReserve": isReserve });
    $.ajaxExtend({
        data: para,
        url: "/Reservation/GetPrice",
        success: function (d) {
            if (d.orderPrice >= 0) {
                $("#decimals").text(d.orderPrice);
            } else {
                $("#decimals").text("?");
            }
        }
    });
};

//无预约下单
function checkSubOrderByNoRes() {
    var order = new Object();
    order.BusinessId = hid;
    order.UserName = $.trim($("#inputName").val());
    if (!checkName(order.UserName)) {
        layer.tips("姓名格式错误", $("#inputName"), { tips: 1 });
        return;
    }
    order.UserTel = $.trim($("#inputPhone").val());
    if (!checkMobile(order.UserTel)) {
        layer.tips("手机号格式错误", $("#inputPhone"), { tips: 1 });
        return;
    }
    order.BuyerRemark = $.trim($("#inputNote").val());
    order.PayType = 1;
    order.OrderAmount = $("#decimals").text();
    order.IsReserve = isReserve;

    //执行创单
    var para = JSON.stringify({ "orderInfo": order, "productInfo": $.trim($("#productInfo").val()) });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Reservation/CreatOrderByNoRes",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (!d.IsSucceed) {
                layer.alert(d.Message, { icon: 2, title: "提示" });
            } else {
                if (!d.IsPay) {
                    window.location.href = "/Reservation/ReservationSuccese?businessId=" + hid;
                    return;
                }
                layer.closeAll("tips");
                if (d.IsWxWeb) {
                    if (d.IsAfreshPay) {
                        layer.confirm("您有重复的预约未支付订单，</br>需要取消后重新预订。", { icon: 3, title: "提示", btn: ["确认取消"] }, function (index) {
                            cancelOrder(d.OrderNumber, index);
                        });
                    } else {
                        tenpayHandler(d);
                    }
                } else {
                    $("#paySucese").attr("onclick", "IsPaySuccese('" + d.OrderNumber + "');");
                    $("#refPay").attr("onclick", "window.location.href ='" + d.PayUrl + "'");
                    if (d.IsAfreshPay) {
                        layer.confirm("您有重复的预约未支付订单，</br>需要取消后重新预订。", { icon: 3, title: "提示", btn: ["确认取消"] }, function (index) {
                            cancelOrder(d.OrderNumber, index);
                        });
                    } else {
                        setTimeout("window.layer.open({ type: 1, title: '', area: ['80%', 'auto'], fix: false, maxmin: false, content: $('#validatePay') })", 3000);
                        window.location.href = d.PayUrl;
                    }
                    //window.layer.open({ type: 1, title: '', area: ['80%', 'auto'], fix: false, maxmin: false, content: $("#validatePay") });
                }
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
};