﻿$(function () {
    $(".people").val("1");
    setHeight(".attentionBtn", ".attentionBtn", 0.4378);
});

function setHeight(area, referenceDom, percent) {
    var wid = $(referenceDom).width();
    var height = wid * percent;
    $(area).height(height);
}
function removeModal(e) {
    var ev = e || window.event || arguments.callee.caller.arguments[0];
    var $target = $(ev.target || ev.currentTarget || ev.srcElement);
    var clickParAttr = $target.parents("div[data-modelFlag=true]").attr("data-modelFlag");
    if ($target.attr("data-modelFlag") !== "true" && clickParAttr !== "true") {
        showToggleModal(".attentionModal", false);
    }
}
function showToggleModal(area, flag) {
    if (flag) {
        $(area).removeClass("domHide");
        return;
    }
    $(area).addClass("domHide");
}

function reserve() {
    var load = window.layer.load(1);
    if ($("input[type='radio']:checked").length < 1) {
        if (load) {
            window.layer.close(load);
        }
        layer.msg("未选中主产品");
        return;
    }
    var productId = $("input[type='radio']:checked").val();;
    var date = $.trim($("#date").val());
    var subId = "";
    $('input[name="checkName"]:checked').each(function () {
        var number = $(this).parent().siblings(".numberP").find(".people").val();
        subId += $(this).val() + "x" + number + "_";
    });
    subId = subId.substring(0, subId.length - 1);
    if (load) {
        window.layer.close(load);
    }
    window.location.href = "/Reservation/FillInInformation?productId=" + productId + "&date=" + date + "&subPid=" + subId;
};

//储备库存
function reserveByReserve() {
    var load = window.layer.load(1);
    if ($("input[type='radio']:checked").length < 1) {
        if (load) {
            window.layer.close(load);
        }
        layer.msg("未选中主产品");
        return;
    }
    var productId = $("input[type='radio']:checked").val();;
    var date = $.trim($("#date").val());
    var subId = "";
    $('input[name="checkName"]:checked').each(function () {
        var number = $(this).parent().siblings(".numberP").find(".people").val();
        subId += $(this).val() + "x" + number + "_";
    });
    subId = subId.substring(0, subId.length - 1);
    if (load) {
        window.layer.close(load);
    }
    window.location.href = "/Reservation/FillInInformationByReserve?productId=" + productId + "&date=" + date + "&subPid=" + subId;
};

//免预约选择
function noRes() {
    var load = window.layer.load(1);
    var productInfo = "";
    $("input[type='checkbox']:checked").each(function () {
        productInfo += $(this).val();
        productInfo += "x" + $(this).parent().siblings(".numberP").find(".people").val() + "_";
    });
    if (productInfo === undefined || productInfo === "" || productInfo === null) {
        if (load) {
            window.layer.close(load);
        }
        layer.msg("未选中产品");
        return;
    }
    productInfo = productInfo.substring(0, productInfo.length - 1);
    if (load) {
        window.layer.close(load);
    }
    window.location.href = "/Reservation/FillInInformationByNoRes?productInfo=" + productInfo;
};

//免预约储备选择
function noResReserve() {
    var load = window.layer.load(1);
    var productInfo = "";
    $("input[type='checkbox']:checked").each(function () {
        productInfo += $(this).val();
        productInfo += "x" + $(this).parent().siblings(".numberP").find(".people").val() + "_";
    });
    if (productInfo === undefined || productInfo === "" || productInfo === null) {
        if (load) {
            window.layer.close(load);
        }
        layer.msg("未选中产品");
        return;
    }
    productInfo = productInfo.substring(0, productInfo.length - 1);
    if (load) {
        window.layer.close(load);
    }
    window.location.href = "/Reservation/FillInInfoByNoResReserve?productInfo=" + productInfo;
};

//人数框
function peopleChange(e) {
    debugger;
    var num = parseInt($(e).val());
    if (isNaN(parseInt($(e).val())) || parseInt($(e).val()) < 1) {
        $(e).val("1");
        num = 1;
    }
    var maxNumber = parseInt($(e).attr("max"));
    if (num >= maxNumber) {
        $(e).val(maxNumber);
        $(e).siblings(".add").addClass("tnone");
    } else {
        $(e).siblings(".add").removeClass("tnone");
    }
    if (num > 1) {
        $(e).siblings(".jian").removeClass("tnone");
    }
    var o = $(e).parent().parent().siblings(".price");
    o.text(parseFloat((parseFloat(o.attr("pic")) * num).toPrecision(12)));
};

//人数加减
function peopleNumber(e, f) {
    var max = parseInt($.trim($(e).parent(".input-group-btn").siblings(".people").attr("max")));
    var curr = parseInt($.trim($(e).parent(".input-group-btn").siblings(".people").val()));
    if (isNaN(curr) || parseInt(curr) < 1) {
        curr = 1;
    }
    var o;
    if (f) {
        curr++;
        $(e).parent(".input-group-btn").siblings(".jian").removeClass("tnone");
        $(e).parent(".input-group-btn").siblings(".people").val(curr);
        o = $(e).parent().parent().parent().siblings(".price");
        o.text(parseFloat((parseFloat(o.attr("pic")) * curr).toPrecision(12)));
        if (curr >= max) {
            $(e).parent(".input-group-btn").addClass("tnone");
        }
    } else {
        if (curr === 1) {
            $(e).parent(".input-group-btn").addClass("tnone");
            $(e).parent(".input-group-btn").siblings(".people").val(curr);
            o = $(e).parent().parent().parent().siblings(".price");
            o.text(parseFloat((parseFloat(o.attr("pic")) * curr).toPrecision(12)));
            return;
        }
        curr--;
        if (curr === 1) {
            $(e).parent(".input-group-btn").addClass("tnone");
        }
        $(e).parent(".input-group-btn").siblings(".add").removeClass("tnone");
        $(e).parent(".input-group-btn").siblings(".people").val(curr);
        o = $(e).parent().parent().parent().siblings(".price");
        o.text(parseFloat((parseFloat(o.attr("pic")) * curr).toPrecision(12)));
    }
};