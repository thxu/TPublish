﻿$(function () {
    queryhotel();
});
function queryhotel(pageIndex, pageSize) {
    pagingQuery(pageIndex, pageSize, "/Reservation/HotelManageVal", getCondition(), queryhotel);
}

function getCondition() {
    var obj = new Object();
    obj.BusinessName = $.trim($("#txtqueryBusinessName").val());
    return obj;
}

// 日期截取
function getCreatDate(creatDate) {
    return creatDate.substring(0, 10);
}
