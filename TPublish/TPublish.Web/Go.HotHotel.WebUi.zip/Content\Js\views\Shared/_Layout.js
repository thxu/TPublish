﻿function logoff() {
    window.layer.confirm("你确定要退出吗", { icon: 3, title: "提示" }, function () {
        logout();
    });
}

function logout() {
    $.ajaxExtend({
        url: "/Home/Logoff",
        type: "POST",
        dataType: "text",
        contentType: "application/x-www-form-urlencoded",
        timeout: 30000,
        success: function (d) {
            window.location.href = d;
        }
    });
}

// 打开修改密码layer
function openUpdateLoginPasswordWindowForm() {
    window.layer.open({
        type: 1,
        title: "修改密码",
        area: ["400px", "auto"],
        content: $("#mima-tk"),
        shade: 0
    });
    $("#txtOriginalPwd").val("");
    $("#txtNewPwd").val("");
    $("#txtConfirmNewPwd").val("");
}

// 修改密码
function updateLoginPassword() {
    if (!validateUpdateLoginPassword()) {
        return false;
    }
    var data = getUpdateLoginPasswordParameters();
    operationAction("/Home/UpdateLoginPassword", data, function (d) {
        defualtSuccessAction(d, logout);
    });
    return false;
}

// 验证修改密码输入参数
function validateUpdateLoginPassword() {
    if (!validateEmpty({ id: "#txtOriginalPwd", msg: "原始密码为空" })) {
        return false;
    }
    if (!validateEmpty({ id: "#txtNewPwd", msg: "新密码为空" })) {
        return false;
    }
    if (!validateEmpty({ id: "#txtConfirmNewPwd", msg: "确认新密码为空" })) {
        return false;
    }
    if ($.trim($("#txtNewPwd").val()) !== $.trim($("#txtConfirmNewPwd").val())) {
        $.layerTips("确认密码不一致", "#txtConfirmNewPwd");
        return false;
    }
    return true;
}

// 获取修改密码参数
function getUpdateLoginPasswordParameters() {
    var obj = new Object();
    obj.OldLoginPwd = hexSha1($.trim($("#txtOriginalPwd").val())).toUpperCase();
    obj.NewLoginPwd = hexSha1($.trim($("#txtNewPwd").val())).toUpperCase();
    return JSON.stringify({ updateLoginPassword: obj });
}

// 关闭窗口
function closeWindowForm(index) {
    if (index) {
        window.layer.close(index);
    } else {
        window.layer.closeAll();
    }
}