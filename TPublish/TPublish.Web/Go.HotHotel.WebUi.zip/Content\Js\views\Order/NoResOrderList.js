﻿$(document).ready(function () {
    // 浏览器点击后退样式问题
    $("#firstMenu li[class='active']").attr("class", "");
    if ($("#firstMenu li[id='F4']").val() != undefined) {
        $("#firstMenu li[id='F4']").attr("class", "active");
    } else {
        $("#firstMenu li[id='F13']").attr("class", "active");
    }
});

var orderNumber;
//修改手机
function upPhone(e, f) {
    orderNumber = f;
    $("#newPhone").val("");
    $("#oldPhone").text(e);
    layer.open({
        type: 1,
        title: '手机修改',
        area: ['360px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#phone-tk')
    });
}
//核销订单
function heXiaoOrder(e) {
    var para = JSON.stringify({ "orderNumber": e });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Order/HeXiaoOrder",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                queryCondition();
                layer.closeAll();
                layer.msg("核销成功");
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
}
// 获取查询条件
function getCondition() {
    var obj = new Object();
    obj.Phone = $.trim($("#txtPhone").val());
    obj.KeyCodes = $.trim($("#txtKeyCodes").val());
    obj.OrderState = $("#selectOrderState").val();
    obj.ReservationStartTime = $.trim($("#resStartTime").val());
    obj.ReservationEndTime = $.trim($("#resEndTime").val());
    obj.BusinessName = $.trim($("#txtBusinessName").val());
    obj.IsNeedReservation = 1;
    return obj;
}

// 查询
function queryCondition(pageIndex, pageSize) {
    pageIndex = pageIndex || 1;
    pageSize = pageSize || 10;
    myPaging({
        pageIndex: pageIndex,
        pageSize: pageSize,
        url: "/Order/OrderListValByNoNeedRes",
        data: getCondition(),
        methodname: queryCondition
    });
    queryOrderTotal();
}

// 分页查询
function myPaging(o) {
    var obj = $.extend(true, {
        tbody: "table#dataList tbody",
        temp: "#temp",
        pager: "#Pager",
        pageIndex: 1,
        pageSize: 10,
        data: null,
        methodname: null,
        url: null,
        success: null
    }, o);
    var pagingCondition = getPaging(obj.pageIndex, obj.pageSize);
    var condition = obj.data;
    condition.Paging = pagingCondition;
    var para = JSON.stringify({ "condition": condition });
    var load;
    $.ajaxExtend({
        data: para,
        url: obj.url,
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            $.each(d.Data, function (index) {
                d.Data[index].Index = index;
            });
            $(obj.tbody).html($(obj.temp).tmpl(d.Data));
            window.myTips("hidLongText");
            drawPagination($(obj.pager), d.Paging.PageIndex, d.Paging.PageSize, d.Paging.RowsCount, obj.methodname);
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
    return false;
}


//核销电子码
function hexiaoKeyCode() {
    $("#txtKeyCode").val("");
    layer.open({
        type: 1,
        title: '核销电子码',
        fix: false, //不固定
        maxmin: false,
        content: $('#hideForm')
    });
}

function keyboardenter(et) {
    if (et.keyCode) {
        if (et.keyCode === 13)
            saveKeyCode();
    } else {
        if (et.which === 13)
            saveKeyCode();
    }
}
function saveKeyCode() {
    var keyCode = $.trim($("#txtKeyCode").val());
    var para = JSON.stringify({ "keyCode": keyCode });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Order/HeXiaoKeyCode",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed) {
                queryCondition();
                layer.closeAll();
                layer.msg("核销成功");
            } else {
                $.layerAlert(d.Message, { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
}

function getOrderState(orderState) {
    if (orderState === 1) {
        return "<span>待支付</span>";
    }
    if (orderState === 2) {
        return "<span style='color:red'>未核销</span>";
    }
    if (orderState === 3) {
        return "<span style='color:green'>已核销</span>";
    }
    if (orderState === 4) {
        return "<span>已取消</span>";
    }
    if (orderState === 5) {
        return "<span>转入退款</span>";
    }
    return "";
}

function sureOrder(orderNumber) {
    var para = JSON.stringify({ "orderNumber": orderNumber });
    var load;
    $.ajaxExtend({
        data: para,
        url: "/Order/SureOrder",
        beforeSend: function () {
            load = window.layer.load(1);
        },
        success: function (d) {
            if (d.IsSucceed === true) {
                $.layerAlert("确认成功", { icon: 1 }, function () {
                    location.reload(true);
                });
            } else {

                $.layerAlert("操作失败", { icon: 2 });
            }
        },
        complete: function () {
            if (load) {
                window.layer.close(load);
            }
        }
    });
}

function reSendMsg(orderNo, type) {
    var url = "/Order/ReSendMsg";
    var data = JSON.stringify({ "orderNo": orderNo, "smsType": type });
    operationAction(url, data, function (res) {
        if (res.IsSucceed) {
            $.layerAlert("操作成功", { icon: 1 }, function () {
                var pageIndex = $(".yemaa").text();
                queryCondition(pageIndex, 10);
            });
        } else {
            $.layerAlert("操作失败", { icon: 2 });
        }
    });
}

//获取时间yyyy-MM-dd
function getDate(d) {
    d = d.replace('-', '/').replace('-', '/');
    var date = new Date(d);
    return date.getFullYear() + "-" + PrefixInteger((date.getMonth() + 1), 2) + "-" + PrefixInteger(date.getDate(), 2).toString();
};
//向前补位 n:位数
function PrefixInteger(num, n) {
    if (parseInt(num) > 9) {
        return num;
    }
    return (Array(n).join(0) + num).slice(-n);
};
function cancelOrder(orderNo) {
    confirmAction("您确认要取消订单么?", function () {
        var url = "/Order/CalcelOrder";
        var data = JSON.stringify({ "orderNo": orderNo });
        operationAction(url, data, function (res) {
            if (res.IsSucceed) {
                $.layerAlert("操作成功", { icon: 1 }, function () {
                    var pageIndex = $(".yemaa").text();
                    queryCondition(pageIndex, 10);
                });
            } else {
                $.layerAlert("操作失败", { icon: 2 });
            }
        });
    });
}

function shonephonediv(orderNo, oldphone) {
    $("#newphone").val("");
    $("#hidorderNo").val(orderNo);
    $("#oldphone").text(oldphone);
    layer.open({
        type: 1,
        title: '手机修改',
        area: ['360px', 'auto'],
        fix: false, //不固定
        maxmin: false,
        content: $('#divnoresphone')
    });
}

// 修改手机
function changephone() {
    var regPhone = /^(1\d{10})$/;
    if (!regPhone.test($.trim($("#newphone").val()))) {
        $.layerAlert("请输入正确的手机号", { icon: 2 });
        return false;
    }
    var para = JSON.stringify({ "orderNo": $("#hidorderNo").val(), "newphone": $.trim($("#newphone").val()) });
    confirmAction("确认修改吗？", function (d) {
        operationAction("/Order/UpdateOrderUserTel", para, function (d) {
            if (d.IsSucceed === true) {
                layer.closeAll();
                $.layerAlert("修改成功", { icon: 1 });
                queryCondition();

            } else {
                $.layerAlert("修改失败", { icon: 2 });
            }

        });
    });

    return false;
}
//查询订单总价
function queryOrderTotal() {
    var para = JSON.stringify({ "condition": getCondition() });
    $.ajaxExtend({
        data: para,
        url: "/Order/QueryOrderTotal",
        success: function (d) {
            $("#keyCodeCount").text(d.KeyCodeCount);
            $("#payMoney").text(d.PayMoney);
            $("#confimOrder").text(d.ToBeConfirmedCount);
            $("#totalId").show();
        }
    });
}

// 下载订单报表
function excelOrderByNoRes() {
    var obj = getCondition();
    obj = JSON.stringify(obj);
    location.href = "/Order/ExportOrdersByNoRes?val=" + obj;
}