﻿function queryCondition(pageIndex, pageSize) {
    var url = "/Order/QueryRefundOrderListByCondition";
    pagingQuery(pageIndex, pageSize, url, getCondition(), queryCondition);
}

function getRefundStatus(status) {
    switch (status) {
        case 1:
            return "申请中";
        case 2:
            return "退款中";
        case 3:
            return "成功";
        case 4:
            return "失败";
        default:
            return "未知";
    }
}

function getCondition() {
    var businessName = $.trim($("#txtBusinessName").val());
    var orderNo = $.trim($("#txtOrderNo").val());
    var productName = $.trim($("#txtProductsName").val());
    var userinfo = $.trim($("#txtUserInfo").val());
    var refundStatus = $.trim($("#selectRefundStatus").val());
    var startTime = $.trim($("#startTime").val());
    var stopTime = $.trim($("#stopTime").val());

    var obj = {
        BusinessName: businessName,
        OrderNo: orderNo,
        ProductsName: productName,
        UserInfo: userinfo,
        RefundStatus: refundStatus,
        StartTime: startTime,
        StopTime: stopTime
    };
    return obj;
}